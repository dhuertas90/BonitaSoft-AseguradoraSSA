http://docs.doctrine-project.org/projects/doctrine-orm/en/latest/reference/tools.html

# php vendor/doctrine/orm/bin/doctrine orm:schema-tool:create
# php vendor/doctrine/orm/bin/doctrine orm:schema-tool:update --force
# php vendor/doctrine/orm/bin/doctrine orm:schema-tool:drop

