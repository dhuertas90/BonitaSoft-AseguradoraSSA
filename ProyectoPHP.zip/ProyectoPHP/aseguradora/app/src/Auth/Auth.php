<?php

namespace App\Auth;

class Auth
{
    public function check($ruta)
    {
        if (isset($_SESSION['user_id'])) {
            $rutas["CLIENTE"] = array("homeprivada_show", "incidente_show",
                "incidente_action", "incidente_status_show",
                "incidente_detalle_show");
            $rutas["EMPLEADO"] = array("homeprivada_empleado_show",
                "empleado_listado_usuarios_show", "empleado_listado_incidentes_show",
                "empleado_detalle_incidente_show");
            if (in_array($ruta, $rutas[$_SESSION['user_level']])) {
                return true;
            }
        }
        return false;
    }

    public function persist($is_auth, $user_level, $user_id, $name)
    {
        $_SESSION['is_auth'] = $is_auth;
        $_SESSION['user_level'] = $user_level;
        $_SESSION['user_id'] = $user_id;
        $_SESSION['name'] = $name;
    }

    public function destroy()
    {
        session_unset();
        session_destroy();
    }

    public function passwordVerify($password, $hash)
    {
        return password_verify($password, $hash);
    }

    public function passwordHash($password)
    {
        $options = [
            'cost' => 11
        ];

        return password_hash($password, PASSWORD_BCRYPT, $options);
    }
}
