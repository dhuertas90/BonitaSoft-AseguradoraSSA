<?php
namespace App\Entity;

use App\Entity;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity
 * @ORM\Table(name="incidentes")
 */
class Incidente
{
    /**
     * @ORM\Id
     * @ORM\Column(name="id", type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\ManyToOne(targetEntity="TipoIncidente")
     * @ORM\JoinColumn(name="tipo_id", referencedColumnName="id")
     */
    protected $tipo;

    /**
     * @ORM\Column(type="datetime")
     */
    protected $fechaCarga;

    /**
     * @ORM\Column(type="datetime")
     */
    protected $fechaIncidente;

    /**
     * @ORM\Column(type="integer", length=8, name="cantidad")
     */
    protected $cantidad;


    /**
     * @ORM\Column(type="text")
     */
    protected $motivo;

    /**
     * @ORM\ManyToOne(targetEntity="EstadoIncidente")
     * @ORM\JoinColumn(name="estado_id", referencedColumnName="id")
     */
    protected $estado;

    /**
     * Many Users have One Address.
     * @ORM\ManyToOne(targetEntity="Usuario")
     * @ORM\JoinColumn(name="usuario_id", referencedColumnName="id")
     */
    protected $usuario;

    /**
     * @ORM\Column(type="text")
     */
    protected $detalle;

    public function __construct() {

    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }


    /**
     * @return mixed
     */
    public function getTipo()
    {
        return $this->tipo;
    }

    /**
     * @return mixed
     */
    public function getCantidad()
    {
        return $this->cantidad;
    }

    /**
     * @param mixed $cantidad
     */
    public function setCantidad($cantidad)
    {
        $this->cantidad = $cantidad;
    }


    /**
     * @param mixed $tipo
     */
    public function setTipo($tipo)
    {
        $this->tipo = $tipo;
    }

    /**
     * @return mixed
     */
    public function getFechaCarga()
    {
        return $this->fechaCarga;
    }

    /**
     * @param mixed $fechaCarga
     */
    public function setFechaCarga($fechaCarga)
    {
        $this->fechaCarga = $fechaCarga;
    }

    /**
     * @return mixed
     */
    public function getFechaIncidente()
    {
        return $this->fechaIncidente;
    }

    /**
     * @param mixed $fechaIncidente
     */
    public function setFechaIncidente($fechaIncidente)
    {
        $this->fechaIncidente = $fechaIncidente;
    }

    /**
     * @return mixed
     */
    public function getMotivoIncidente()
    {
        return $this->motivo;
    }

    /**
     * @param mixed $motivo
     */
    public function setMotivoIncidente($motivo)
    {
        $this->motivo = $motivo;
    }

    /**
     * @return mixed
     */
    public function getEstado()
    {
        return $this->estado;
    }

    /**
     * @param mixed $estado
     */
    public function setEstado($estado)
    {
        $this->estado = $estado;
    }

    /**
     * @return mixed
     */
    public function getUsuario()
    {
        return $this->usuario;
    }

    /**
     * @param mixed $usuario
     */
    public function setUsuario($usuario)
    {
        $this->usuario = $usuario;
    }

    /**
     * @return mixed
     */
    public function getDetalleObjetosIncidente()
    {
        return $this->detalle;
    }

    /**
     * @param mixed $detalle
     */
    public function setDetalleObjetosIncidente($detalle)
    {
        $this->detalle = $detalle;
    }
}
