<?php

namespace App\Bonita;

use App\Entity\Incidente;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Cookie\SessionCookieJar;

class Cliente
{

    private $usuario;
    private $password;
    private $url;
    private $nombreDiagrama;
    private $cliente;
    private $token;

    public function __construct($usuario, $password, $url, $nombreDiagrama)
    {
        $this->usuario = $usuario;
        $this->password = $password;
        $this->url = $url;
        $this->nombreDiagrama = $nombreDiagrama;
    }

    private function conectarse()
    {

        $cookieJar = new SessionCookieJar('X-Bonita-API-Token', true);

        $this->cliente = new Client([
            'base_uri' => $this->url,
            'timeout'  => 4.0,
            'cookies' => $cookieJar
        ]);

        try {
            $this->cliente->request('POST', 'loginservice', [
                'form_params' => [
                    'username' => $this->usuario,
                    'password' => $this->password,
                    'redirect' => 'false'
                ]
            ]);

            $cookie = $this->cliente->getConfig('cookies');
            $data = $cookie->toArray();

            while (list(, $val) = each($data)) {
                if ($val["Name"] == 'X-Bonita-API-Token') {
                    $this->token = $val["Value"];
                    break;
                }
            }

            $_SESSION['user_bonita']= $this->usuario;
            $_SESSION['password_bonita']= $this->password;
            $_SESSION['base_uri_bonita']= $this->url;
            $_SESSION['logged'] = true;
            $_SESSION['token_bonita'] = $this->token;

            return false;
        } catch (RequestException $e) {
            if ($e->hasResponse()) {
                $error = Psr7\str($e->getResponse());
            } else {
                $error = "No se puede conectar al servidor de Bonita OS";
            }
            return $error;
        }
    }

    public function instanciarProceso(Incidente $incidente)
    {
        $this->conectarse();

        try {
            $request = $this->cliente->request('GET', 'API/bpm/process?p=0&c=1000');

            $tareas = $request->getBody();
            $response['data'] = json_decode($tareas);

            while (list(, $val) = each($response['data'])) {
                if ($val->name == $this->nombreDiagrama) {
                    $code = $val->id;
                    break;
                }
            }

            $numeroExpediente["name"] = "vp_numeroExpediente";
            $numeroExpediente["value"] = $incidente->getId();

            $documento["name"] = "vp_documento";
            $documento["value"] = $incidente->getUsuario()->getPersona()->getDocumento();

            $tipoIncidente["name"] = "vp_tipoIncidente";
            $tipoIncidente["value"] = $incidente->getTipo()->getId();

            $situacionProdujo["name"] = "vp_situacionIncidente";
            $situacionProdujo["value"] = $incidente->getMotivoIncidente();

            $fechaIncidente["name"] = "vp_fechaIncidente";
            $fechaIncidente["value"] = $incidente->getFechaIncidente()->format('d-m-Y');

            $cantidadObjetos["name"] = "vp_cantidadObjetos";
            $cantidadObjetos["value"] = $incidente->getCantidad();

            $descripcionObjetos["name"] = "vp_descripcionObjetos";
            $descripcionObjetos["value"] = $incidente->getDetalleObjetosIncidente();

            $emailUsuario["name"] = "vp_email";
            $emailUsuario["value"] = $incidente->getUsuario()->getEmail();

            $nombreUsuario["name"] = "vp_nombre";
            $nombreUsuario["value"] = $incidente->getUsuario()->getPersona()->getNombre();

            $data = array(
                "processDefinitionId" => $code,
                "variables" => array
                (
                    $numeroExpediente,$documento,$tipoIncidente,$situacionProdujo,
                    $fechaIncidente,$cantidadObjetos,$descripcionObjetos,$emailUsuario,$nombreUsuario
                ),
            );

            $result = $this->cliente->request(
                'POST',
                "API/bpm/case",
                ['json' => $data,'headers' => ['X-Bonita-API-Token' => $this->token]]
            );
            return $result;
        } catch (RequestException $e) {
            if ($e->hasResponse()) {
                $error = Psr7\str($e->getResponse());
            } else {
                $error = "No se puede conectar al servidor de Bonita OS";
            }
            return $error;
        }
    }
}
