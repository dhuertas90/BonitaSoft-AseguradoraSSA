<?php

namespace App\Action;

use App\Entity\Incidente;
use App\Entity\IncidenteDetalle;
use Slim\Views\Twig;
use Psr\Log\LoggerInterface;
use Slim\Http\Request;
use Slim\Http\Response;
use Slim\Flash\Messages;
use App\Auth\Auth;

final class EmpleadoAction
{
    private $view;
    private $logger;
    private $flash;
    private $auth;
    private $usuarioResource;
    private $incidenteResource;

    public function __construct(
        Twig $view,
        LoggerInterface $logger,
        Messages $flash,
        Auth $auth,
        $usuarioResource,
        $incidenteResource
    ) {
        $this->view = $view;
        $this->logger = $logger;
        $this->flash = $flash;
        $this->auth = $auth;
        $this->usuarioResource = $usuarioResource;
        $this->incidenteResource = $incidenteResource;
    }

    public function homeEmpleadoPrivadaShow(Request $request, Response $response, $args)
    {
        if (!$this->auth->check($request->getAttribute('route')->getName())) {
            $this->flash->addMessage('error', 'Debe iniciar sesión para acceder a ésta página!');
            return $response->withStatus(302)->withHeader('Location', '/');
        }

        $this->logger->info("Accedimos a la Home Privada");

        $this->view->render($response, 'empleado/homePrivada.twig');

        return $response;
    }

    public function empleadoListadoUsuariosShow(Request $request, Response $response, $args)
    {
        if (!$this->auth->check($request->getAttribute('route')->getName())) {
            $this->flash->addMessage('error', 'Debe iniciar sesión para acceder a ésta página!');
            return $response->withStatus(302)->withHeader('Location', '/');
        }

        $listado_usuarios = $this->usuarioResource->get();

        $this->view->render($response, 'empleado/listadoUsuarios.twig', array(
            'listado_usuarios' => $listado_usuarios,
        ));

        return $response;
    }

    public function empleadoListadoIncidentesShow(Request $request, Response $response, $args)
    {
        if (!$this->auth->check($request->getAttribute('route')->getName())) {
            $this->flash->addMessage('error', 'Debe iniciar sesión para acceder a ésta página!');
            return $response->withStatus(302)->withHeader('Location', '/');
        }

        $listado_incidentes = $this->incidenteResource->get();

        $this->view->render($response, 'empleado/listadoIncidentes.twig', array(
            'listado_incidentes' => $listado_incidentes,
        ));

        return $response;
    }


    public function empleadoDetalleIncidenteShow(Request $request, Response $response, $args)
    {
        if (!$this->auth->check($request->getAttribute('route')->getName())) {
            $this->flash->addMessage('error', 'Debe iniciar sesión para acceder a ésta página!');
            return $response->withStatus(302)->withHeader('Location', '/');
        }

        if (!isset($args['id'])) {
            $this->flash->addMessage('error', 'Error. No existe el incidente!');
            return $response->withRedirect('/empleado/listadoIncidentes');
        }

        $id = $args['id'];
        $incidente = $this->incidenteResource->getById($id, "ADMIN");

        if (!$incidente) {
            $this->flash->addMessage('error', 'Error. No existe el incidente!');
            return $response->withRedirect('/empleado/listadoIncidentes');
        }

        $this->view->render($response, 'empleado/detalleIncidente.twig', array(
            'incidente' => $incidente,
        ));

        return $response;
    }
}
