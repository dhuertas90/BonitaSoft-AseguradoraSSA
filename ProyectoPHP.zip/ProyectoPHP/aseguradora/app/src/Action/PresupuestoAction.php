<?php
namespace App\Action;

use App\Resource\ProveedorResource;
use Psr\Log\LoggerInterface;

final class PresupuestoAction
{
    private $proveedorResource;
    private $logger;

    public function __construct(ProveedorResource $proveedorResource, LoggerInterface $logger)
    {
        $this->proveedorResource = $proveedorResource;
        $this->logger = $logger;
    }

    /*
     * http://localhost/api/provider2/token/123456/objeto/objeto1,objeto2/cantidad/10,20
     * */
    private function armadoPresupuesto($token, $productos, $cantidades)
    {
        $productos = explode(",", $productos);
        $cantidades = explode(",", $cantidades);

        $sumatoria = 0;
        $tablaPresupuesto = array();

        $providerOne["presupuesto"] = 0;
        if ((count($productos) != count($cantidades)) || !count($productos>0)) {
            return -1;
        } else {

            $tablaPresupuesto[0][0] = "Producto";
            $tablaPresupuesto[0][1] = "Cantidad";
            $tablaPresupuesto[0][2] = "Precio Unitario";
            $tablaPresupuesto[0][3] = "Precio Total";

            for ($i = 0; $i < count($cantidades); $i++) {
                $precioUnitario = rand(1, 50);
                if (is_numeric($cantidades[$i])) {
                    $precioTotal = $precioUnitario * $cantidades[$i];
                }
                else{
                    $precioTotal = 0;
                }
                $sumatoria = $sumatoria + $precioTotal;
                //Desconvierto el uglify
                $tablaPresupuesto[$i+1][0] = str_replace("-", " ", $productos[$i]);
                $tablaPresupuesto[$i+1][1] = is_numeric($cantidades[$i])?$cantidades[$i]:0;
                $tablaPresupuesto[$i+1][2] = strval($precioUnitario);
                $tablaPresupuesto[$i+1][3] = strval($precioTotal);
            }
            $precioTotalListado["presupuesto"] = strval($sumatoria);
            $tablaPresupuesto = array($precioTotalListado,$tablaPresupuesto);
        }
        return $tablaPresupuesto;
    }

    public function providerOne($request, $response, $args)
    {
        $this->logger->info("UNO: $args:".print_r($args,true));

        if ($args['token'] != "123456") {
            return $response->withJSON("Token no valido", 401);
        }

        $retorno = $this->armadoPresupuesto($args['token'],$args["objeto_detalle"], $args["cantidad_detalle"]);
        if ($retorno == -1) {
            return $response->withJSON("Inconsistencia en los parametros", 400);
        }

        $this->logger->info("UNO: $args:".print_r($retorno,true));
        return $response->withJSON($retorno,200);
    }

    public function providerTwo($request, $response, $args)
    {
        $this->logger->info("DOS: $args:".print_r($args,true));
        if ($args['token'] != "123456") {
            return $response->withJSON("Token no valido", 401);
        }

        $retorno = $this->armadoPresupuesto($args['token'],$args["objeto_detalle"], $args["cantidad_detalle"]);
        if ($retorno == -1) {
            return $response->withJSON("Inconsistencia en los parametros", 400);
        }

        $this->logger->info("UNO: $args:".print_r($retorno,true));
        return $response->withJSON($retorno,200);
    }
}
