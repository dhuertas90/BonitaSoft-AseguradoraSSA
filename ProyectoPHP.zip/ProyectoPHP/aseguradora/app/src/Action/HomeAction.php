<?php

namespace App\Action;

use App\Entity\Usuario;
use Slim\Views\Twig;
use Slim\Http\Request;
use Slim\Http\Response;
use Slim\Flash\Messages;
use App\Auth\Auth;
use Psr\Log\LoggerInterface;

final class HomeAction
{
    private $view;
    private $logger;
    private $flash;
    private $auth;
    private $usuarioResource;
    private $clienteResource;
    private $empleadoResource;
    private $rolResource;
    private $personaResource;

    public function __construct(
        Twig $view,
        LoggerInterface $logger,
        Messages $flash,
        Auth $auth,
        $usuarioResource,
        $clienteResource,
        $empleadoResource,
        $rolResource,
        $personaResource
    ) {
        $this->view = $view;
        $this->logger = $logger;
        $this->flash = $flash;
        $this->auth = $auth;
        $this->usuarioResource = $usuarioResource;
        $this->clienteResource = $clienteResource;
        $this->empleadoResource = $empleadoResource;
        $this->rolResource = $rolResource;
        $this->personaResource = $personaResource;
    }

    public function iniciarSesionShow(Request $request, Response $response, $args)
    {
        $this->view->render($response, 'home/iniciarSesion.twig');

        return $response;
    }

    public function registrarseShow(Request $request, Response $response, $args)
    {
        $this->view->render($response, 'home/registrarse.twig');

        return $response;
    }

    public function registrarseAction(Request $request, Response $response, $args)
    {
        if (!isset($_POST['email']) || !isset($_POST['password']) || !isset($_POST['cliente']) ||
            !isset($_POST['documento'])) {
                $this->flash->addMessage('error', 'Debe completar todos los datos para registrarse!');
                return $response->withRedirect('/registrarse_show');
        }

        $nroIdentificacion = $_POST['cliente'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $documento = $_POST['documento'];

        $usuarioEstaRegistrado = $this->usuarioResource->get($email);

        $clienteAseguradora = $this->clienteResource->get($nroIdentificacion, $documento);

        if (!$clienteAseguradora) {
            $empleadoAseguradora = $this->empleadoResource->get($nroIdentificacion, $documento);
        }

        if ((!$clienteAseguradora && !$empleadoAseguradora) || $usuarioEstaRegistrado) {
            $this->flash->addMessage('error', 'Usted no cumple condiciones para registrarse. O esta registrado!');
            return $response->withStatus(302)->withHeader('Location', '/registrarse_show');
        }

        $usuarioWeb = new Usuario();
        $usuarioWeb->setActivo(true);
        $persona = $this->personaResource->get($documento);
        $usuarioWeb->setPersona($persona);
        $usuarioWeb->setEmail($email);
        $usuarioWeb->setPassword($this->auth->passwordHash($password));

        ($clienteAseguradora) ? $rol = $this->rolResource->get("CLIENTE") : $rol = $this->rolResource->get("EMPLEADO");

        $usuarioWeb->setRol($rol);
        $this->usuarioResource->persist($usuarioWeb);

        $this->logger->info("registrarse_Action");

        $this->flash->addMessage('exito', 'Registrado Correctamente. Acceda al sitio Web!');

        return $response->withStatus(302)->withHeader('Location', '/');
    }


    public function iniciarSesionAction(Request $request, Response $response, $args)
    {
        if (isset($_POST['registrarse'])) {
            return $response->withRedirect('/registrarse_show');
        }

        if (isset($_POST['olvido_password'])) {
            return $response->withRedirect('/olvidopassword_show');
        }

        if (!isset($_POST['email']) || !isset($_POST['password'])) {
            $this->flash->addMessage('error', 'Debe completar todos los datos para iniciar sesion!');
            return $response->withRedirect('/registrarse_show');
        }

        $email = $_POST['email'];
        $password = $_POST['password'];

        $usuarioWeb = $this->usuarioResource->get($email);

        if (!$usuarioWeb || !$this->auth->passwordVerify($password, $usuarioWeb->getPassword())) {
            $this->flash->addMessage('error', 'Correo Electrónico o Password no Válidos!');
            return $response->withStatus(302)->withHeader('Location', '/');
        }

        $this->auth->persist(
            true,
            $usuarioWeb->getRol()->getNombre(),
            $usuarioWeb->getPersona()->getDocumento(),
            $email
        );

        $this->logger->info("iniciarSesion_Action");

        if ($usuarioWeb->getRol()->getNombre() == "EMPLEADO") {
            return $response->withStatus(302)->withHeader('Location', '/empleado/inicio');
        }
        return $response->withStatus(302)->withHeader('Location', '/usuario/inicio');
    }

    public function cerrarSesionAction(Request $request, Response $response, $args)
    {
        $this->auth->destroy();

        $this->logger->info("cerrarSesion_Action");

        return $response->withStatus(302)->withHeader('Location', '/');
    }

    public function olvidoPasswordShow(Request $request, Response $response, $args)
    {
        $this->logger->info("olvidoPassword_Show");

        $this->view->render($response, 'home/olvidoPassword.twig');

        return $response;
    }

    public function olvidoPasswordAction(Request $request, Response $response, $args)
    {

        if (!isset($_POST['cliente']) || !isset($_POST['documento']) || !isset($_POST['password'])) {
            $this->flash->addMessage('error', 'Debe completar los datos para continuar!');
            return $response->withRedirect('/olvidopassword_show');
        }

        $nroIdentificacion = $_POST['cliente'];
        $documento = $_POST['documento'];
        $password = $_POST['password'];

        $cliente = $this->clienteResource->get($nroIdentificacion, $documento);

        if (!$cliente) {
            $this->flash->addMessage('error', 'Usted no cumple condiciones para recuperar clave!');
            return $response->withStatus(302)->withHeader('Location', '/olvidopassword_show');
        }

        $persona = $this->personaResource->get($documento);
        $usuario_registrado = $this->usuarioResource->getByPersona($persona->getId());

        if ($usuario_registrado) {
            $usuario_registrado->setActivo(true);
            $usuario_registrado->setPassword($this->auth->passwordHash($password));
            $this->usuarioResource->merge($usuario_registrado);
        }

        $this->logger->info("olvidoPassword_Action");

        $this->flash->addMessage('exito', 'Cambio de Clave Generado con Exito!');

        return $response->withStatus(302)->withHeader('Location', '/');
    }
}
