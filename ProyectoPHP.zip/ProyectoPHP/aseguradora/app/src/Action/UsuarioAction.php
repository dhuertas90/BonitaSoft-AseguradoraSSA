<?php

namespace App\Action;

use App\Entity\Incidente;
use Slim\Views\Twig;
use Psr\Log\LoggerInterface;
use Slim\Http\Request;
use Slim\Http\Response;
use Slim\Flash\Messages;
use App\Auth\Auth;

final class UsuarioAction
{
    private $view;
    private $logger;
    private $flash;
    private $auth;
    private $usuarioResource;
    private $incidenteResource;
    private $bonitaResource;
    private $tipoIncidenteResource;
    private $estadoIncidenteResource;

    public function __construct(
        Twig $view,
        LoggerInterface $logger,
        Messages $flash,
        Auth $auth,
        $usuarioResource,
        $incidenteResource,
        $bonitaResource,
        $tipoIncidenteResource,
        $estadoIncidenteResource
    ) {
        $this->view = $view;
        $this->logger = $logger;
        $this->flash = $flash;
        $this->auth = $auth;
        $this->usuarioResource = $usuarioResource;
        $this->incidenteResource = $incidenteResource;
        $this->bonitaResource = $bonitaResource;
        $this->tipoIncidenteResource = $tipoIncidenteResource;
        $this->estadoIncidenteResource = $estadoIncidenteResource;
    }

    public function homePrivadaShow(Request $request, Response $response, $args)
    {
        if (!$this->auth->check($request->getAttribute('route')->getName())) {
            $this->flash->addMessage('error', 'Debe iniciar sesión para acceder a ésta página!');
            return $response->withStatus(302)->withHeader('Location', '/');
        }

        $this->view->render($response, 'usuario/homePrivada.twig');

        return $response;
    }

    public function incidenteShow(Request $request, Response $response, $args)
    {
        if (!$this->auth->check($request->getAttribute('route')->getName())) {
            $this->flash->addMessage('error', 'Debe iniciar sesión para acceder a ésta página!');
            return $response->withStatus(302)->withHeader('Location', '/');
        }

        $this->logger->info("Accedimos a la Home Privada");
        $tiposIncidentes = $this->tipoIncidenteResource->get();

        $this->view->render($response, 'usuario/incidente.twig', array(
            'tiposIncidentes' => $tiposIncidentes,
        ));

        return $response;
    }

    public function incidenteAction(Request $request, Response $response, $args)
    {
        if (!$this->auth->check($request->getAttribute('route')->getName())) {
            $this->flash->addMessage('error', 'Debe iniciar sesión para acceder a ésta página!');
            return $response->withStatus(302)->withHeader('Location', '/');
        }

        if (!isset($_POST['tipo_incidente']) || !isset($_POST['motivo_incidente']) ||
            !isset($_POST['fecha_incidente']) ||
            strlen($_POST['fecha_incidente']) <= 1 || !isset($_POST['cantidad_objeto'])
            || !isset($_POST['descripcion_objetos'])
            || strlen($_POST['motivo_incidente']) <= 1 || strlen($_POST['descripcion_objetos']) <= 1
        ) {
            $this->flash->addMessage('error', 'Debe completar todos los datos para cargar el incidente!');
            return $response->withRedirect('/usuario/incidente_show');
        }

        try {
            $fecha_elegida = new \DateTime($_POST["fecha_incidente"]);
        } catch (\Exception $e) {
            $this->flash->addMessage('error', 'El formato de fecha ingresado no es correcto.!');
            return $response->withRedirect('/usuario/incidente_show');
        }

        $incidente = new Incidente();

        $estadoIncidente = $this->estadoIncidenteResource->get("VISOR");
        $incidente->setEstado($estadoIncidente);
        $incidente->setFechaCarga(new \DateTime('NOW'));
        $incidente->setFechaIncidente($fecha_elegida);
        $incidente->setMotivoIncidente($_POST["motivo_incidente"]);
        $tiposIncidente = $this->tipoIncidenteResource->getById($_POST["tipo_incidente"]);
        $incidente->setTipo($tiposIncidente);

        $usuario_registrado = $this->usuarioResource->get($_SESSION["name"]);
        $incidente->setUsuario($usuario_registrado);
        $incidente->setCantidad($_POST['cantidad_objeto']);
        $incidente->setDetalleObjetosIncidente($_POST['descripcion_objetos']);

        $this->incidenteResource->persist($incidente);

        $this->bonitaResource->instanciarProceso($incidente);

        $this->flash->addMessage('exito', 'El incidente se cargo correctamente!');

        return $response->withStatus(302)->withHeader('Location', '/usuario/inicio');
    }


    public function incidenteStatusShow(Request $request, Response $response, $args)
    {
        if (!$this->auth->check($request->getAttribute('route')->getName())) {
            $this->flash->addMessage('error', 'Debe iniciar sesión para acceder a ésta página!');
            return $response->withStatus(302)->withHeader('Location', '/');
        }

        $usuario_registrado = $this->usuarioResource->get($_SESSION["name"]);
        $listadoIncidentes = $this->incidenteResource->get($usuario_registrado);

        $this->logger->info("Accedimos a la Home Privada");

        $this->view->render($response, 'usuario/incidenteEstado.twig', array(
            'incidentes' => $listadoIncidentes,
        ));

        return $response;
    }

    public function incidenteDetalleShow(Request $request, Response $response, $args)
    {
        if (!$this->auth->check($request->getAttribute('route')->getName())) {
            $this->flash->addMessage('error', 'Debe iniciar sesión para acceder a ésta página!');
            return $response->withStatus(302)->withHeader('Location', '/');
        }

        if (!isset($args['id'])) {
            $this->flash->addMessage('error', 'Error. No existe el incidente!');
            return $response->withRedirect('/usuario/incidente_status_show');
        }

        $id = $args['id'];
        $usuario_registrado = $this->usuarioResource->get($_SESSION["name"]);
        $incidente = $this->incidenteResource->getById($id, $usuario_registrado);

        if (!$incidente) {
            $this->flash->addMessage('error', 'Error. No existe el incidente!');
            return $response->withRedirect('/usuario/incidente_status_show');
        }

        $this->view->render($response, 'usuario/incidenteDetalle.twig', array(
            'incidente' => $incidente,
        ));

        return $response;
    }
}
