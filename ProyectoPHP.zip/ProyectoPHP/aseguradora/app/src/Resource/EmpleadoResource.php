<?php

namespace App\Resource;

use App\AbstractResource;

/**
 * Class Resource
 * @package App
 */
class EmpleadoResource extends AbstractResource
{
    /**
     * @param string|null $slug
     *
     * @return array
     */
    public function get($nro_identificacion,$documento)
    {
        if ($nro_identificacion === null && $documento === null) {
            $empleados = $this->entityManager->getRepository('App\Entity\Empleado')->findAll();
            return $empleados;

        } else {
            $empleado = $this->entityManager->getRepository('App\Entity\Empleado')->findOneBy(
                array('legajo' => $nro_identificacion,'documento' => $documento)
            );
            if ($empleado) {
                return $empleado;
            }
        }
        return false;
    }
}
