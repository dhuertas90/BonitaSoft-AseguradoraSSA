<?php

namespace App\Resource;

use App\AbstractResource;

/**
 * Class Resource
 * @package App
 */
class TipoIncidenteResource extends AbstractResource
{
    /**
     * @param string|null $slug
     *
     * @return array
     */
    public function get($nombre)
    {
        if ($nombre === null) {
            $roles = $this->entityManager->getRepository('App\Entity\TipoIncidente')->findAll();
            return $roles;

        } else {
            $rol = $this->entityManager->getRepository('App\Entity\TipoIncidente')->findOneBy(
                array('nombre' => $nombre)
            );
            if ($rol) {
                return $rol;
            }
        }
        return false;
    }

    public function getById($id)
    {
        $tipo = $this->entityManager->getRepository('App\Entity\TipoIncidente')->findOneBy(
            array('id' => $id)
        );
        if ($tipo) {
            return $tipo;
        }

        return false;
    }


}
