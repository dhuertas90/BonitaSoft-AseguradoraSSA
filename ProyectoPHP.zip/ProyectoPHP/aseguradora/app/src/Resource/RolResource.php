<?php

namespace App\Resource;

use App\AbstractResource;

/**
 * Class Resource
 * @package App
 */
class RolResource extends AbstractResource
{
    /**
     * @param string|null $slug
     *
     * @return array
     */
    public function get($nombre)
    {
        if ($nombre === null) {
            $roles = $this->entityManager->getRepository('App\Entity\Rol')->findAll();
            return $roles;

        } else {
            $rol = $this->entityManager->getRepository('App\Entity\Rol')->findOneBy(
                array('nombre' => $nombre)
            );
            if ($rol) {
                return $rol;
            }
        }
        return false;
    }
}
