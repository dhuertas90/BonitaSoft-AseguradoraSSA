<?php

namespace App\Resource;

use App\AbstractResource;
use App\Entity\Usuario;

/**
 * Class Resource
 * @package App
 */
class IncidenteResource extends AbstractResource
{
    public function get($usuario = null)
    {
        if ($usuario === null) {
            $incidentes = $this->entityManager->getRepository('App\Entity\Incidente')->findAll();
            return $incidentes;

        } else {
            $incidente = $this->entityManager->getRepository('App\Entity\Incidente')->findBy(
                array('usuario' => $usuario)
            );
            if ($incidente) {
                return $incidente;
            }
        }

        return false;
    }

    public function getById($id = null, $usuario = null)
    {
        if($usuario == "ADMIN")
        {
            $incidente = $this->entityManager->getRepository('App\Entity\Incidente')->findOneBy(
                array('id' => $id)
            );
        }
        else{
            $incidente = $this->entityManager->getRepository('App\Entity\Incidente')->findOneBy(
                array('usuario' => $usuario,'id' => $id)
            );
        }

        if ($incidente) {
            return $incidente;
        }
        return false;
    }



    public function persist($incidente)
    {
        $this->entityManager->persist($incidente);
        $this->entityManager->flush();
    }





}
