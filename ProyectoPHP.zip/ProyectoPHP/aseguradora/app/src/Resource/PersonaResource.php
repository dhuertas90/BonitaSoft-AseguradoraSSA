<?php

namespace App\Resource;

use App\AbstractResource;
use App\Entity\Cliente;

/**
 * Class Resource
 * @package App
 */
class PersonaResource extends AbstractResource
{
    /**
     * @param string|null $slug
     *
     * @return array
     */
    public function get($documento)
    {
        if ($documento === null) {
            $personas = $this->entityManager->getRepository('App\Entity\Persona')->findAll();
            return $personas;

        } else {
            $stop = 1;
            $persona = $this->entityManager->getRepository('App\Entity\Persona')->findOneBy(
                array('documento' => $documento)
            );
            if ($persona) {
                return $persona;
            }
        }
        return false;
    }
}
