<?php

namespace App\Resource;

use App\AbstractResource;
use App\Entity\Cliente;

/**
 * Class Resource
 * @package App
 */
class ClienteResource extends AbstractResource
{
    /**
     * @param string|null $slug
     *
     * @return array
     */
    public function get($nro_identificacion,$documento)
    {
        if ($nro_identificacion === null && $documento === null) {
            $clientes = $this->entityManager->getRepository('App\Entity\Cliente')->findAll();
            return $clientes;

        } else {
            $stop = 1;
            $cliente = $this->entityManager->getRepository('App\Entity\Cliente')->findOneBy(
                array('codigo' => $nro_identificacion,'documento' => $documento)
            );
            if ($cliente) {
                return $cliente;
            }
        }
        return false;
    }
}
