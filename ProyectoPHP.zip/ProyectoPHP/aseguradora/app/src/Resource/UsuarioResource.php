<?php

namespace App\Resource;

use App\AbstractResource;
use App\Entity\Usuario;

/**
 * Class Resource
 * @package App
 */
class UsuarioResource extends AbstractResource
{
    /**
     * @param string|null $slug
     *
     * @return array
     */
    public function get($email = null)
    {
        if ($email === null) {
            $usuarios = $this->entityManager->getRepository('App\Entity\Usuario')->findAll();
            return $usuarios;

        } else {
            $usuario = $this->entityManager->getRepository('App\Entity\Usuario')->findOneBy(
                array('email' => $email)
            );
            if ($usuario) {
                return $usuario;
            }
        }

        return false;
    }

    public function getByPersona($id = null)
    {
        $usuario = $this->entityManager->getRepository('App\Entity\Usuario')->findOneBy(
            array('persona' => $id)
        );
        if ($usuario) {
            return $usuario;
        }

        return false;
    }

    public function persist($usuario)
    {
        $this->entityManager->persist($usuario);
        $this->entityManager->flush();
    }

    public function merge($usuario)
    {
        $this->entityManager->merge($usuario);
        $this->entityManager->flush();
    }


}
