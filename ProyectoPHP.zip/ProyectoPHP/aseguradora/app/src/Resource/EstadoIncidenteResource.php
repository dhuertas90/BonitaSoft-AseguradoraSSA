<?php

namespace App\Resource;

use App\AbstractResource;

/**
 * Class Resource
 * @package App
 */
class EstadoIncidenteResource extends AbstractResource
{
    /**
     * @param string|null $slug
     *
     * @return array
     */
    public function get($nombre)
    {
        if ($nombre === null) {
            $roles = $this->entityManager->getRepository('App\Entity\EstadoIncidente')->findAll();
            return $roles;

        } else {
            $rol = $this->entityManager->getRepository('App\Entity\EstadoIncidente')->findOneBy(
                array('nombre' => $nombre)
            );
            if ($rol) {
                return $rol;
            }
        }
        return false;
    }
}
