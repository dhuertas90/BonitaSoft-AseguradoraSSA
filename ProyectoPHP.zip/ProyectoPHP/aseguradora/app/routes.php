<?php

/*
 * Rutas Publicas
 * */

//localhost
$app->get('/', 'App\Action\HomeAction:iniciarSesionShow')
    ->setName('iniciarsesion_show');

//localhost/registrarse_show
$app->get('/registrarse_show', 'App\Action\HomeAction:registrarseShow')
    ->setName('registrarse_show');

//localhost/registrarse_action
$app->post('/registrarse_action', 'App\Action\HomeAction:registrarseAction')
    ->setName('registrarse_action');

//localhost/iniciarsesion_action
$app->post('/iniciarsesion_action', 'App\Action\HomeAction:iniciarSesionAction')
    ->setName('iniciarsesion_action');

//localhost/cerrarsesion_action
$app->get('/cerrarsesion_action', 'App\Action\HomeAction:cerrarSesionAction')
    ->setName('cerrarsesion_action');

//localhost/olvidopassword_show
$app->get('/olvidopassword_show', 'App\Action\HomeAction:olvidoPasswordShow')
    ->setName('olvidopassword_show');

//localhost/olvidopassword_action
$app->post('/olvidopassword_action', 'App\Action\HomeAction:olvidoPasswordAction')
    ->setName('olvidopassword_action');

/*
 * Rutas Privadas Usuario
 * */

//localhost/usuario/inicio
$app->get('/usuario/inicio', 'App\Action\UsuarioAction:homePrivadaShow')
    ->setName('homeprivada_show');

//localhost/usuario/incidente_show
$app->get('/usuario/incidente_show', 'App\Action\UsuarioAction:incidenteShow')
    ->setName('incidente_show');

//localhost/usuario/incidente_action
$app->post('/usuario/incidente_action', 'App\Action\UsuarioAction:incidenteAction')
    ->setName('incidente_action');

//localhost/usuario/incidente_status_show
$app->get('/usuario/incidente_status_show', 'App\Action\UsuarioAction:incidenteStatusShow')
    ->setName('incidente_status_show');

//localhost/usuario/incidente_detalle/1
$app->get('/usuario/incidente_detalle/{id}', 'App\Action\UsuarioAction:incidenteDetalleShow')
    ->setName('incidente_detalle_show');

/*
 * Rutas Privadas Empleado
 * */

//localhost/empleado/inicio
$app->get('/empleado/inicio', 'App\Action\EmpleadoAction:homeEmpleadoPrivadaShow')
    ->setName('homeprivada_empleado_show');

//localhost/empleado/listado_usuarios
$app->get('/empleado/listado_usuarios', 'App\Action\EmpleadoAction:empleadoListadoUsuariosShow')
    ->setName('empleado_listado_usuarios_show');

//localhost/empleado/listado_incidentes
$app->get('/empleado/listado_incidentes', 'App\Action\EmpleadoAction:empleadoListadoIncidentesShow')
    ->setName('empleado_listado_incidentes_show');

//localhost/empleado/incidente_detalle/1
$app->get('/empleado/incidente_detalle/{id}', 'App\Action\EmpleadoAction:empleadoDetalleIncidenteShow')
    ->setName('empleado_detalle_incidente_show');


/*
 *
 * Rutas API
 * https://stackoverflow.com/questions/2602043/rest-api-best-practice-how-to-accept-list-of-parameter-values-as-input
 * localhost/api/provider1/objeto/aaa,bbb,ccc/cantidad/10,20,30
 * */

$app->get('/api/provider1/token/{token}/objeto/{objeto_detalle}/cantidad/{cantidad_detalle}', 'App\Action\PresupuestoAction:providerOne');

$app->get('/api/provider2/token/{token}/objeto/{objeto_detalle}/cantidad/{cantidad_detalle}', 'App\Action\PresupuestoAction:providerTwo');
