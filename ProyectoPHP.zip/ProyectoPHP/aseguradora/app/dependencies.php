<?php
// DIC configuration

$container = $app->getContainer();

// -----------------------------------------------------------------------------
// Service providers
// -----------------------------------------------------------------------------

// Twig
$container['view'] = function ($c) {
    $settings = $c->get('settings');
    $view = new \Slim\Views\Twig($settings['view']['template_path'], $settings['view']['twig']);

    // Add extensions
    $view->addExtension(new Slim\Views\TwigExtension($c->get('router'), $c->get('request')->getUri()));
    $view->addExtension(new Twig_Extension_Debug());

    return $view;
};

// Flash messages

$container['flash'] = function () {
    return new \Slim\Flash\Messages;
};

$container['auth'] = function () {
    return new App\Auth\Auth();
};

$container['bonita'] = function ($c) {
    $settings = $c->get('settings');
    $usuario = $settings['bonita']['usuario'];
    $password = $settings['bonita']['password'];
    $url = $settings['bonita']['url'];
    $nombreDiagrama = $settings['bonita']['nombreDiagrama'];
    return new App\Bonita\Cliente($usuario, $password, $url, $nombreDiagrama);
};

//Override the default Not Found Handler
$container['notFoundHandler'] = function ($c) {
    return function ($request, $response) use ($c) {
        return $c['view']->render($response->withStatus(404), '404.twig', [
            "Parametros" => "Test"
        ]);
    };
};

$container['notAllowedHandler'] = function ($c) {
    return function ($request, $response) use ($c) {
        return $c['view']->render($response->withStatus(405), '405.twig', [
            "Parametros" => "Test"
        ]);
    };
};


// -----------------------------------------------------------------------------
// Service factories
// -----------------------------------------------------------------------------

// monolog
$container['logger'] = function ($c) {
    $settings = $c->get('settings');
    $logger = new \Monolog\Logger($settings['logger']['name']);
    $logger->pushProcessor(new \Monolog\Processor\UidProcessor());
    $logger->pushHandler(new \Monolog\Handler\StreamHandler($settings['logger']['path'], \Monolog\Logger::DEBUG));
    return $logger;
};

// Doctrine
$container['em'] = function ($c) {
    $settings = $c->get('settings');
    $config = \Doctrine\ORM\Tools\Setup::createAnnotationMetadataConfiguration(
        $settings['doctrine']['meta']['entity_path'],
        $settings['doctrine']['meta']['auto_generate_proxies'],
        $settings['doctrine']['meta']['proxy_dir'],
        $settings['doctrine']['meta']['cache'],
        false
    );
    return \Doctrine\ORM\EntityManager::create($settings['doctrine']['connection'], $config);
};

// -----------------------------------------------------------------------------
// Action factories
// -----------------------------------------------------------------------------

$container['App\Action\HomeAction'] = function ($c) {
    //return new App\Action\HomeAction($c->get('view'), $c->get('logger'),$c->get('flash'));
    $usuarioResource = new \App\Resource\UsuarioResource($c->get('em'));
    $clienteResource = new \App\Resource\ClienteResource($c->get('em'));
    $empleadoResource = new \App\Resource\EmpleadoResource($c->get('em'));
    $rolResource = new \App\Resource\RolResource($c->get('em'));
    $personaResource = new \App\Resource\PersonaResource($c->get('em'));

    return new App\Action\HomeAction($c->get('view'), $c->get('logger'),$c->get('flash'),
        $c->get('auth'),$usuarioResource,$clienteResource,$empleadoResource,$rolResource,$personaResource
    );
};

$container['App\Action\UsuarioAction'] = function ($c) {
    $tipoIncidenteResource = new \App\Resource\TipoIncidenteResource($c->get('em'));
    $estadoIncidenteResource = new \App\Resource\EstadoIncidenteResource($c->get('em'));
    $usuarioResource = new \App\Resource\UsuarioResource($c->get('em'));
    $incidenteResource = new \App\Resource\IncidenteResource($c->get('em'));
    return new App\Action\UsuarioAction($c->get('view'), $c->get('logger'),$c->get('flash'),
        $c->get('auth'),$usuarioResource,$incidenteResource,$c->get('bonita'),
        $tipoIncidenteResource,$estadoIncidenteResource);
};

$container['App\Action\EmpleadoAction'] = function ($c) {
    $usuarioResource = new \App\Resource\UsuarioResource($c->get('em'));
    $incidenteResource = new \App\Resource\IncidenteResource($c->get('em'));
    return new App\Action\EmpleadoAction($c->get('view'), $c->get('logger'),$c->get('flash'),
        $c->get('auth'),$usuarioResource,$incidenteResource);
};

$container['App\Action\PresupuestoAction'] = function ($c) {
    $proveedorResource = new \App\Resource\ProveedorResource($c->get('em'));
    return new App\Action\PresupuestoAction($proveedorResource,$c->get('logger'));
};

