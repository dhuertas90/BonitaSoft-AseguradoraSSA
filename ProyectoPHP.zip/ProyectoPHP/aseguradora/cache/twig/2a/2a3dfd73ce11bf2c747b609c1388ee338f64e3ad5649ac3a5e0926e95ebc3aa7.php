<?php

/* restapi/test_upload_ws.twig */
class __TwigTemplate_4ab9def655a0ef703ad29a1451f31abc36d847c478572b45c6655c0e062da15b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>

<head>
    <title>File Upload </title>

    <script
            src=\"https://code.jquery.com/jquery-3.2.1.js\"
            integrity=\"sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE=\"
            crossorigin=\"anonymous\"></script>


</head>

<body>


<form id=\"request\">
    Select image to upload:
    <input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\">
    <input type=\"submit\" value=\"Upload Image\" name=\"submit\">
</form>


<script>
    function fun()
    {
        var data=\"hello\";
        \$.get(\"http://localhost:81/api/sample\", function(response) {
            data = response;
        }).error(function(){
            alert(\"Sorry could not proceed\");
        });

        console.debug(\"Devuelvo: \" + data);
        return data;
    }

    \$(function(){
        \$(\"#request\").on(\"submit\", function(e){
            \$.ajax({
                url: 'http://localhost:81/api/samplepost',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                type: 'post',
                data: \"1234\",
                dataType: 'json',
                success: function (result) {
                    console.log(result);
                },
                error: function () {
                    console.log(\"error\");
                }});
            e.preventDefault();
        });
    });






</script>



</body>
</html>";
    }

    public function getTemplateName()
    {
        return "restapi/test_upload_ws.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>

<head>
    <title>File Upload </title>

    <script
            src=\"https://code.jquery.com/jquery-3.2.1.js\"
            integrity=\"sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE=\"
            crossorigin=\"anonymous\"></script>


</head>

<body>


<form id=\"request\">
    Select image to upload:
    <input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\">
    <input type=\"submit\" value=\"Upload Image\" name=\"submit\">
</form>


<script>
    function fun()
    {
        var data=\"hello\";
        \$.get(\"http://localhost:81/api/sample\", function(response) {
            data = response;
        }).error(function(){
            alert(\"Sorry could not proceed\");
        });

        console.debug(\"Devuelvo: \" + data);
        return data;
    }

    \$(function(){
        \$(\"#request\").on(\"submit\", function(e){
            \$.ajax({
                url: 'http://localhost:81/api/samplepost',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                type: 'post',
                data: \"1234\",
                dataType: 'json',
                success: function (result) {
                    console.log(result);
                },
                error: function () {
                    console.log(\"error\");
                }});
            e.preventDefault();
        });
    });






</script>



</body>
</html>", "restapi/test_upload_ws.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\restapi\\test_upload_ws.twig");
    }
}
