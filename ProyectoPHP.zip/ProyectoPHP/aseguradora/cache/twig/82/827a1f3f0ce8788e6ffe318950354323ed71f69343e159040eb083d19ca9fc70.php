<?php

/* 404.twig */
class __TwigTemplate_2ed4b1d8827c83b69bb177e4b25700af76fe05f3b6ea7e7c7aab7201e5bb0444 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<p>Error 404 notFoundHandler </p>";
    }

    public function getTemplateName()
    {
        return "404.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<p>Error 404 notFoundHandler </p>", "404.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\404.twig");
    }
}
