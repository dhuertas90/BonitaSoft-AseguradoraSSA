<?php

/* empleado/detalleIncidente.twig */
class __TwigTemplate_2690f7014a1f06f650046d7de46b2c15d9b954526beb77fb6250f851bdcc20de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "empleado/detalleIncidente.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css_adicional' => array($this, 'block_css_adicional'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Incidente Detalle";
    }

    // line 5
    public function block_css_adicional($context, array $blocks = array())
    {
        // line 6
        echo "
    <style>

        body {
            padding-top: 20px;
        }

        .footer {
            padding-top: 40px;
            padding-bottom: 40px;
            margin-top: 40px;
            border-top: 1px solid #eee;
        }

        /* Main marketing message and sign up button */
        .jumbotron {
            text-align: center;
            background-color: transparent;
        }
        .jumbotron .btn {
            padding: 14px 24px;
            font-size: 21px;
        }

        .navbar {
            background-image: -webkit-gradient(linear, left top, left bottom, from(#f7f7f7),to(#eee));
            background-image: -webkit-linear-gradient(top, #f7f7f7 0%,#eee 100%);
            background-image: -o-linear-gradient(top, #f7f7f7 0%,#eee 100%);
            background-image: linear-gradient(to bottom, #f7f7f7 0%,#eee 100%);
            border: 1px solid #e5e5e5;
        }

        @media (min-width: 768px) {
            .navbar-nav {
                display: -webkit-box;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: flex;
            }

            .navbar-nav .nav-item {
                -webkit-box-flex: 1;
                -webkit-flex: 1 0 auto;
                -ms-flex: 1 0 auto;
                flex: 1 0 auto;
            }
        }

        /* Responsive: Portrait tablets and up */
        @media screen and (min-width: 768px) {
            /* Remove the padding we set earlier */
            .masthead,
            .marketing,
            .footer {
                padding-right: 0;
                padding-left: 0;
            }
        }


        .hide {
            display: none!important;
        }


    </style>

";
    }

    // line 75
    public function block_content($context, array $blocks = array())
    {
        // line 76
        echo "


    ";
        // line 79
        $this->loadTemplate("helper/headerPrivadoEmpleado.twig", "empleado/detalleIncidente.twig", 79)->display($context);
        // line 80
        echo "


    ";
        // line 83
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method", false, true), 0, array(), "array", true, true)) {
            // line 84
            echo "        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> ";
            // line 85
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 88
        echo "
    ";
        // line 89
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method", false, true), 0, array(), "array", true, true)) {
            // line 90
            echo "        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Atención!</strong> ";
            // line 91
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 94
        echo "


    <!-- Example row of columns -->
    <div class=\"row\">

        <div class=\"col-md-6 offset-md-3\">

            <form class=\"\" action=\"/usuario/incidente_action\" method=\"post\">



                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Tipo Incidente:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" name=\"tipo_incidente\" readonly value=\"";
        // line 109
        echo twig_escape_filter($this->env, twig_trim_filter($this->getAttribute($this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "tipo", array()), "nombre", array())), "html", null, true);
        echo "\" class=\"form-control\" />
                    </div>
                </div>





                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Documento:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" value=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "usuario", array()), "persona", array()), "documento", array()), "html", null, true);
        echo "\" name=\"documento\" readonly class=\"form-control\" />
                    </div>
                </div>




                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Situación o Motivo por el cual se produjo el incidente:</u></label>
                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\"   readonly required rows=\"3\" name=\"motivo_incidente\">";
        // line 129
        echo twig_escape_filter($this->env, twig_trim_filter($this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "getMotivoIncidente", array())), "html", null, true);
        echo "</textarea>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Fecha Incidente:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" value=\"";
        // line 135
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "fechaIncidente", array()), "d-m-Y"), "html", null, true);
        echo "\" name=\"fecha_incidente\" readonly class=\"form-control\" />
                    </div>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Fecha Carga:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" name=\"fecha_incidente\" value=\"";
        // line 142
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "fechaCarga", array()), "d-m-Y"), "html", null, true);
        echo "\" readonly class=\"form-control\" />
                    </div>
                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Cantidad:</u></label>
                    <input class=\"form-control\" type=\"number\" name=\"cantidad_objeto\" min=\"1\"  readonly max=\"50\" value=\"";
        // line 149
        echo twig_escape_filter($this->env, twig_trim_filter($this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "cantidad", array())), "html", null, true);
        echo "\" required id=\"example-number-input\">
                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Descripción de cada objeto a idemnizar:</u> Utilize el formato
                        Nombre Objeto / cantidad Objeto / Descripción del incidente sobre objeto</label>


                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\" required rows=\"3\" readonly name=\"descripcion_objetos\">";
        // line 158
        echo twig_escape_filter($this->env, twig_trim_filter($this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "getDetalleObjetosIncidente", array())), "html", null, true);
        echo "</textarea>



                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Estado:</u></label>
                    <div id=\"sandbox-container\">
                        <input type=\"text\" type=\"text\" name=\"estado\" readonly value=\"";
        // line 167
        echo twig_escape_filter($this->env, twig_trim_filter($this->getAttribute($this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "estado", array()), "nombre", array())), "html", null, true);
        echo "\" class=\"form-control\" />
                    </div>
                </div>









                </br>

            </form>




        </div>

    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

";
    }

    public function getTemplateName()
    {
        return "empleado/detalleIncidente.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  246 => 167,  234 => 158,  222 => 149,  212 => 142,  202 => 135,  193 => 129,  181 => 120,  167 => 109,  150 => 94,  144 => 91,  141 => 90,  139 => 89,  136 => 88,  130 => 85,  127 => 84,  125 => 83,  120 => 80,  118 => 79,  113 => 76,  110 => 75,  39 => 6,  36 => 5,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block title %}Incidente Detalle{% endblock %}

{% block css_adicional %}

    <style>

        body {
            padding-top: 20px;
        }

        .footer {
            padding-top: 40px;
            padding-bottom: 40px;
            margin-top: 40px;
            border-top: 1px solid #eee;
        }

        /* Main marketing message and sign up button */
        .jumbotron {
            text-align: center;
            background-color: transparent;
        }
        .jumbotron .btn {
            padding: 14px 24px;
            font-size: 21px;
        }

        .navbar {
            background-image: -webkit-gradient(linear, left top, left bottom, from(#f7f7f7),to(#eee));
            background-image: -webkit-linear-gradient(top, #f7f7f7 0%,#eee 100%);
            background-image: -o-linear-gradient(top, #f7f7f7 0%,#eee 100%);
            background-image: linear-gradient(to bottom, #f7f7f7 0%,#eee 100%);
            border: 1px solid #e5e5e5;
        }

        @media (min-width: 768px) {
            .navbar-nav {
                display: -webkit-box;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: flex;
            }

            .navbar-nav .nav-item {
                -webkit-box-flex: 1;
                -webkit-flex: 1 0 auto;
                -ms-flex: 1 0 auto;
                flex: 1 0 auto;
            }
        }

        /* Responsive: Portrait tablets and up */
        @media screen and (min-width: 768px) {
            /* Remove the padding we set earlier */
            .masthead,
            .marketing,
            .footer {
                padding-right: 0;
                padding-left: 0;
            }
        }


        .hide {
            display: none!important;
        }


    </style>

{% endblock %}

{% block content %}



    {% include 'helper/headerPrivadoEmpleado.twig' %}



    {% if flash.message('error')[0] is defined %}
        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> {{ flash.message('error')[0] }}
        </div>
    {% endif %}

    {% if flash.message('exito')[0] is defined %}
        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Atención!</strong> {{ flash.message('exito')[0] }}
        </div>
    {% endif %}



    <!-- Example row of columns -->
    <div class=\"row\">

        <div class=\"col-md-6 offset-md-3\">

            <form class=\"\" action=\"/usuario/incidente_action\" method=\"post\">



                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Tipo Incidente:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" name=\"tipo_incidente\" readonly value=\"{{ incidente.tipo.nombre|trim}}\" class=\"form-control\" />
                    </div>
                </div>





                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Documento:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" value=\"{{ incidente.usuario.persona.documento}}\" name=\"documento\" readonly class=\"form-control\" />
                    </div>
                </div>




                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Situación o Motivo por el cual se produjo el incidente:</u></label>
                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\"   readonly required rows=\"3\" name=\"motivo_incidente\">{{ incidente.getMotivoIncidente|trim}}</textarea>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Fecha Incidente:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" value=\"{{ incidente.fechaIncidente|date('d-m-Y')}}\" name=\"fecha_incidente\" readonly class=\"form-control\" />
                    </div>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Fecha Carga:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" name=\"fecha_incidente\" value=\"{{ incidente.fechaCarga|date('d-m-Y')}}\" readonly class=\"form-control\" />
                    </div>
                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Cantidad:</u></label>
                    <input class=\"form-control\" type=\"number\" name=\"cantidad_objeto\" min=\"1\"  readonly max=\"50\" value=\"{{ incidente.cantidad |trim}}\" required id=\"example-number-input\">
                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Descripción de cada objeto a idemnizar:</u> Utilize el formato
                        Nombre Objeto / cantidad Objeto / Descripción del incidente sobre objeto</label>


                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\" required rows=\"3\" readonly name=\"descripcion_objetos\">{{ incidente.getDetalleObjetosIncidente|trim}}</textarea>



                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Estado:</u></label>
                    <div id=\"sandbox-container\">
                        <input type=\"text\" type=\"text\" name=\"estado\" readonly value=\"{{ incidente.estado.nombre|trim}}\" class=\"form-control\" />
                    </div>
                </div>









                </br>

            </form>




        </div>

    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

{% endblock %}






















", "empleado/detalleIncidente.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\empleado\\detalleIncidente.twig");
    }
}
