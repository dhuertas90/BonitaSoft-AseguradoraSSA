<?php

/* usuario/homePrivada.twig */
class __TwigTemplate_64f89f0d71a43ad9e50744a7b04fae75e2d1e73aac6d3f934c703a5bd4413ca1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "usuario/homePrivada.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css_adicional' => array($this, 'block_css_adicional'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Parte Privada";
    }

    // line 5
    public function block_css_adicional($context, array $blocks = array())
    {
        // line 6
        echo "    <link rel=\"stylesheet\" href=\"css/usuario/homePrivada.css\">
";
    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        // line 10
        echo "
    ";
        // line 11
        $this->loadTemplate("helper/headerPrivado.twig", "usuario/homePrivada.twig", 11)->display($context);
        // line 12
        echo "

    ";
        // line 14
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method", false, true), 0, array(), "array", true, true)) {
            // line 15
            echo "        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> ";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 19
        echo "
    ";
        // line 20
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method", false, true), 0, array(), "array", true, true)) {
            // line 21
            echo "        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Exito!</strong> ";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 25
        echo "

    <!-- Example row of columns -->
    <div class=\"row\">
        <div class=\"col-lg-4\">
        </div>
        <div class=\"col-lg-4\">
        </div>
        <div class=\"col-lg-4\">
        </div>
    </div>

    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

";
    }

    public function getTemplateName()
    {
        return "usuario/homePrivada.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 25,  75 => 22,  72 => 21,  70 => 20,  67 => 19,  61 => 16,  58 => 15,  56 => 14,  52 => 12,  50 => 11,  47 => 10,  44 => 9,  39 => 6,  36 => 5,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block title %}Parte Privada{% endblock %}

{% block css_adicional %}
    <link rel=\"stylesheet\" href=\"css/usuario/homePrivada.css\">
{% endblock %}

{% block content %}

    {% include 'helper/headerPrivado.twig' %}


    {% if flash.message('error')[0] is defined %}
        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> {{ flash.message('error')[0] }}
        </div>
    {% endif %}

    {% if flash.message('exito')[0] is defined %}
        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Exito!</strong> {{ flash.message('exito')[0] }}
        </div>
    {% endif %}


    <!-- Example row of columns -->
    <div class=\"row\">
        <div class=\"col-lg-4\">
        </div>
        <div class=\"col-lg-4\">
        </div>
        <div class=\"col-lg-4\">
        </div>
    </div>

    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

{% endblock %}
















", "usuario/homePrivada.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\usuario\\homePrivada.twig");
    }
}
