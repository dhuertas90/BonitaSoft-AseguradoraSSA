<?php

/* usuario/incidenteDetalle.twig */
class __TwigTemplate_0043e7e4b9e2b3999149df8d9144ec15abd458869822ae9eb8b44b6be68e450f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "usuario/incidenteDetalle.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css_adicional' => array($this, 'block_css_adicional'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Incidente Detalle";
    }

    // line 5
    public function block_css_adicional($context, array $blocks = array())
    {
        // line 6
        echo "    <link rel=\"stylesheet\" href=\"css/usuario/incidenteDetalle.css\">
";
    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
        // line 12
        echo "


    ";
        // line 15
        $this->loadTemplate("helper/headerPrivado.twig", "usuario/incidenteDetalle.twig", 15)->display($context);
        // line 16
        echo "    <!-- Jumbotron -->




    ";
        // line 21
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method", false, true), 0, array(), "array", true, true)) {
            // line 22
            echo "        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> ";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 26
        echo "
    ";
        // line 27
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method", false, true), 0, array(), "array", true, true)) {
            // line 28
            echo "        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Atención!</strong> ";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 32
        echo "


    <!-- Example row of columns -->
    <div class=\"row\">

        <div class=\"col-md-6 offset-md-3\">

            <form class=\"\" action=\"/usuario/incidente_action\" method=\"post\">



                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Tipo Incidente:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" name=\"tipo_incidente\" readonly value=\"";
        // line 47
        echo twig_escape_filter($this->env, twig_trim_filter($this->getAttribute($this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "tipo", array()), "nombre", array())), "html", null, true);
        echo "\" class=\"form-control\" />
                    </div>
                </div>










                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Situación o Motivo por el cual se produjo el incidente:</u></label>
                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\"   readonly required rows=\"3\" name=\"motivo_incidente\">";
        // line 62
        echo twig_escape_filter($this->env, twig_trim_filter($this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "getMotivoIncidente", array())), "html", null, true);
        echo "</textarea>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Fecha Incidente:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" value=\"";
        // line 68
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "fechaIncidente", array()), "d-m-Y"), "html", null, true);
        echo "\" name=\"fecha_incidente\" readonly class=\"form-control\" />
                    </div>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Fecha Carga:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" name=\"fecha_incidente\" value=\"";
        // line 75
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "fechaCarga", array()), "d-m-Y"), "html", null, true);
        echo "\" readonly class=\"form-control\" />
                    </div>
                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Cantidad de Objetos a Idemnizar:</u></label>
                    <input class=\"form-control\" type=\"number\" name=\"cantidad_objeto\" min=\"1\"  readonly max=\"50\" value=\"";
        // line 82
        echo twig_escape_filter($this->env, twig_trim_filter($this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "cantidad", array())), "html", null, true);
        echo "\" required id=\"example-number-input\">
                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Descripción de cada objeto a idemnizar:</u> Utilize el formato
                        Nombre Objeto / cantidad Objeto / Descripción del incidente sobre objeto</label>


                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\" required rows=\"3\" readonly name=\"descripcion_objetos\">";
        // line 91
        echo twig_escape_filter($this->env, twig_trim_filter($this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "getDetalleObjetosIncidente", array())), "html", null, true);
        echo "</textarea>



                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Estado:</u></label>
                    <div id=\"sandbox-container\">
                        <input type=\"text\" type=\"text\" name=\"estado\" readonly value=\"";
        // line 100
        echo twig_escape_filter($this->env, twig_trim_filter($this->getAttribute($this->getAttribute((isset($context["incidente"]) ? $context["incidente"] : null), "estado", array()), "nombre", array())), "html", null, true);
        echo "\" class=\"form-control\" />
                    </div>
                </div>









                </br>

            </form>




        </div>

    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

";
    }

    public function getTemplateName()
    {
        return "usuario/incidenteDetalle.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  174 => 100,  162 => 91,  150 => 82,  140 => 75,  130 => 68,  121 => 62,  103 => 47,  86 => 32,  80 => 29,  77 => 28,  75 => 27,  72 => 26,  66 => 23,  63 => 22,  61 => 21,  54 => 16,  52 => 15,  47 => 12,  44 => 11,  39 => 6,  36 => 5,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block title %}Incidente Detalle{% endblock %}

{% block css_adicional %}
    <link rel=\"stylesheet\" href=\"css/usuario/incidenteDetalle.css\">
{% endblock %}



{% block content %}



    {% include 'helper/headerPrivado.twig' %}
    <!-- Jumbotron -->




    {% if flash.message('error')[0] is defined %}
        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> {{ flash.message('error')[0] }}
        </div>
    {% endif %}

    {% if flash.message('exito')[0] is defined %}
        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Atención!</strong> {{ flash.message('exito')[0] }}
        </div>
    {% endif %}



    <!-- Example row of columns -->
    <div class=\"row\">

        <div class=\"col-md-6 offset-md-3\">

            <form class=\"\" action=\"/usuario/incidente_action\" method=\"post\">



                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Tipo Incidente:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" name=\"tipo_incidente\" readonly value=\"{{ incidente.tipo.nombre|trim}}\" class=\"form-control\" />
                    </div>
                </div>










                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Situación o Motivo por el cual se produjo el incidente:</u></label>
                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\"   readonly required rows=\"3\" name=\"motivo_incidente\">{{ incidente.getMotivoIncidente|trim}}</textarea>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Fecha Incidente:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" value=\"{{ incidente.fechaIncidente|date('d-m-Y')}}\" name=\"fecha_incidente\" readonly class=\"form-control\" />
                    </div>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Fecha Carga:</u></label>
                    <div id=\"\">
                        <input type=\"text\" type=\"text\" name=\"fecha_incidente\" value=\"{{ incidente.fechaCarga|date('d-m-Y')}}\" readonly class=\"form-control\" />
                    </div>
                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Cantidad de Objetos a Idemnizar:</u></label>
                    <input class=\"form-control\" type=\"number\" name=\"cantidad_objeto\" min=\"1\"  readonly max=\"50\" value=\"{{ incidente.cantidad |trim}}\" required id=\"example-number-input\">
                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Descripción de cada objeto a idemnizar:</u> Utilize el formato
                        Nombre Objeto / cantidad Objeto / Descripción del incidente sobre objeto</label>


                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\" required rows=\"3\" readonly name=\"descripcion_objetos\">{{ incidente.getDetalleObjetosIncidente|trim}}</textarea>



                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Estado:</u></label>
                    <div id=\"sandbox-container\">
                        <input type=\"text\" type=\"text\" name=\"estado\" readonly value=\"{{ incidente.estado.nombre|trim}}\" class=\"form-control\" />
                    </div>
                </div>









                </br>

            </form>




        </div>

    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

{% endblock %}






















", "usuario/incidenteDetalle.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\usuario\\incidenteDetalle.twig");
    }
}
