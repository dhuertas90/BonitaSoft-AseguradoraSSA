<?php

/* empleado/listadoUsuarios.twig */
class __TwigTemplate_adb6cd937494ff196838045e5cc10cb2c4dff796d7fecb0cfb0a0c11bf25f86a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "empleado/listadoUsuarios.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css_adicional' => array($this, 'block_css_adicional'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Incidente Detalle";
    }

    // line 5
    public function block_css_adicional($context, array $blocks = array())
    {
        // line 6
        echo "
    <style>

        body {
            padding-top: 20px;
        }

        .footer {
            padding-top: 40px;
            padding-bottom: 40px;
            margin-top: 40px;
            border-top: 1px solid #eee;
        }

        /* Main marketing message and sign up button */
        .jumbotron {
            text-align: center;
            background-color: transparent;
        }
        .jumbotron .btn {
            padding: 14px 24px;
            font-size: 21px;
        }

        .navbar {
            background-image: -webkit-gradient(linear, left top, left bottom, from(#f7f7f7),to(#eee));
            background-image: -webkit-linear-gradient(top, #f7f7f7 0%,#eee 100%);
            background-image: -o-linear-gradient(top, #f7f7f7 0%,#eee 100%);
            background-image: linear-gradient(to bottom, #f7f7f7 0%,#eee 100%);
            border: 1px solid #e5e5e5;
        }

        @media (min-width: 768px) {
            .navbar-nav {
                display: -webkit-box;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: flex;
            }

            .navbar-nav .nav-item {
                -webkit-box-flex: 1;
                -webkit-flex: 1 0 auto;
                -ms-flex: 1 0 auto;
                flex: 1 0 auto;
            }
        }

        /* Responsive: Portrait tablets and up */
        @media screen and (min-width: 768px) {
            /* Remove the padding we set earlier */
            .masthead,
            .marketing,
            .footer {
                padding-right: 0;
                padding-left: 0;
            }
        }


        .hide {
            display: none!important;
        }


    </style>

";
    }

    // line 75
    public function block_content($context, array $blocks = array())
    {
        // line 76
        echo "


    ";
        // line 79
        $this->loadTemplate("helper/headerPrivadoEmpleado.twig", "empleado/listadoUsuarios.twig", 79)->display($context);
        // line 80
        echo "

    ";
        // line 82
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method", false, true), 0, array(), "array", true, true)) {
            // line 83
            echo "        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> ";
            // line 84
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 87
        echo "
    ";
        // line 88
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method", false, true), 0, array(), "array", true, true)) {
            // line 89
            echo "        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Exito!</strong> ";
            // line 90
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 93
        echo "
    <!-- Example row of columns -->
    <div class=\"row\">

        <div class=\"col-md-9 offset-md-3\">




            <h2>Listado de Usuario</h2>

            <table class=\"table\">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Rol</th>
                    <th>Documento</th>
                    <th>Email</th>
                    <th>Activo</th>
                </tr>
                </thead>
                <tbody>

                ";
        // line 116
        $context["i"] = 1;
        // line 117
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listado_usuarios"]) ? $context["listado_usuarios"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["usuario"]) {
            // line 118
            echo "                    <tr class=\"table-success\">
                        <th scope=\"row\">";
            // line 119
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "</th>
                        <td>";
            // line 120
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["usuario"], "rol", array()), "nombre", array()));
            echo "</td>
                        <td>";
            // line 121
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["usuario"], "persona", array()), "documento", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 122
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "email", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 123
            echo ((($this->getAttribute($context["usuario"], "activo", array()) == 1)) ? ("Si") : ("No"));
            echo "</td>
                    </tr>
                    ";
            // line 125
            $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
            // line 126
            echo "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['usuario'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 127
        echo "





                </tbody>
            </table>


        </div>

    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

";
    }

    public function getTemplateName()
    {
        return "empleado/listadoUsuarios.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  213 => 127,  207 => 126,  205 => 125,  200 => 123,  196 => 122,  192 => 121,  188 => 120,  184 => 119,  181 => 118,  176 => 117,  174 => 116,  149 => 93,  143 => 90,  140 => 89,  138 => 88,  135 => 87,  129 => 84,  126 => 83,  124 => 82,  120 => 80,  118 => 79,  113 => 76,  110 => 75,  39 => 6,  36 => 5,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block title %}Incidente Detalle{% endblock %}

{% block css_adicional %}

    <style>

        body {
            padding-top: 20px;
        }

        .footer {
            padding-top: 40px;
            padding-bottom: 40px;
            margin-top: 40px;
            border-top: 1px solid #eee;
        }

        /* Main marketing message and sign up button */
        .jumbotron {
            text-align: center;
            background-color: transparent;
        }
        .jumbotron .btn {
            padding: 14px 24px;
            font-size: 21px;
        }

        .navbar {
            background-image: -webkit-gradient(linear, left top, left bottom, from(#f7f7f7),to(#eee));
            background-image: -webkit-linear-gradient(top, #f7f7f7 0%,#eee 100%);
            background-image: -o-linear-gradient(top, #f7f7f7 0%,#eee 100%);
            background-image: linear-gradient(to bottom, #f7f7f7 0%,#eee 100%);
            border: 1px solid #e5e5e5;
        }

        @media (min-width: 768px) {
            .navbar-nav {
                display: -webkit-box;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: flex;
            }

            .navbar-nav .nav-item {
                -webkit-box-flex: 1;
                -webkit-flex: 1 0 auto;
                -ms-flex: 1 0 auto;
                flex: 1 0 auto;
            }
        }

        /* Responsive: Portrait tablets and up */
        @media screen and (min-width: 768px) {
            /* Remove the padding we set earlier */
            .masthead,
            .marketing,
            .footer {
                padding-right: 0;
                padding-left: 0;
            }
        }


        .hide {
            display: none!important;
        }


    </style>

{% endblock %}

{% block content %}



    {% include 'helper/headerPrivadoEmpleado.twig' %}


    {% if flash.message('error')[0] is defined %}
        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> {{ flash.message('error')[0] }}
        </div>
    {% endif %}

    {% if flash.message('exito')[0] is defined %}
        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Exito!</strong> {{ flash.message('exito')[0] }}
        </div>
    {% endif %}

    <!-- Example row of columns -->
    <div class=\"row\">

        <div class=\"col-md-9 offset-md-3\">




            <h2>Listado de Usuario</h2>

            <table class=\"table\">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Rol</th>
                    <th>Documento</th>
                    <th>Email</th>
                    <th>Activo</th>
                </tr>
                </thead>
                <tbody>

                {% set i = 1%}
                {% for usuario in listado_usuarios %}
                    <tr class=\"table-success\">
                        <th scope=\"row\">{{ i }}</th>
                        <td>{{ usuario.rol.nombre|e }}</td>
                        <td>{{ usuario.persona.documento }}</td>
                        <td>{{ usuario.email }}</td>
                        <td>{{ (usuario.activo == 1) ? 'Si':'No' }}</td>
                    </tr>
                    {%set i = i + 1%}
                {% endfor %}






                </tbody>
            </table>


        </div>

    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

{% endblock %}
























", "empleado/listadoUsuarios.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\empleado\\listadoUsuarios.twig");
    }
}
