<?php

/* home/iniciarSesion.twig */
class __TwigTemplate_c2d0d8b7756e3917821f85108627aef24e697e5be8ac238a04d7575a9fe4b202 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "home/iniciarSesion.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css_adicional' => array($this, 'block_css_adicional'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Iniciar Sesión";
    }

    // line 5
    public function block_css_adicional($context, array $blocks = array())
    {
        // line 6
        echo "    <link rel=\"stylesheet\" href=\"css/home/iniciarSesion.css\">
";
    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        // line 10
        echo "
    <form class=\"form-signin\" action=\"/iniciarsesion_action\" method=\"post\">
        <h2 class=\"form-signin-heading\">Acceso al Sitio Web</h2>
        ";
        // line 13
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method", false, true), 0, array(), "array", true, true)) {
            // line 14
            echo "            <div class=\"alert alert-danger\" role=\"alert\">
                <strong>Atención!</strong> ";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method"), 0, array(), "array"), "html", null, true);
            echo "
            </div>
        ";
        }
        // line 18
        echo "
        ";
        // line 19
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method", false, true), 0, array(), "array", true, true)) {
            // line 20
            echo "            <div class=\"alert alert-success\" role=\"alert\">
                <strong>Atención!</strong> ";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method"), 0, array(), "array"), "html", null, true);
            echo "
            </div>
        ";
        }
        // line 24
        echo "
        <label for=\"inputEmail\" class=\"sr-only\">Correo Electrónico</label>
        <input name=\"email\" maxlength=\"30\" minlength=\"3\" type=\"text\" id=\"inputEmail\" class=\"form-control\" placeholder=\"Correo Electrónico\" required autofocus>

        <label for=\"inputPassword\" class=\"sr-only\">Password</label>
        <input name =\"password\" maxlength=\"10\" minlength=\"3\" type=\"password\" id=\"inputPassword\" class=\"form-control\" placeholder=\"Password\" required>

        <input class=\"btn btn-primary btn-sm btn-block\" name=\"acceder\" type=\"submit\" value=\"Iniciar Sesión\">
        <input class=\"btn btn-secondary btn-sm btn-block\" name=\"registrarse\" type=\"submit\" value=\"Registrarse\" onclick=\"location.href = '/registrarse_show';\">
        <input class=\"btn btn-info btn-sm btn-block\" name=\"olvido_password\" type=\"submit\" value=\"Recuperar Password\" onclick=\"location.href = '/olvidopassword_show';\">
    </form>
";
    }

    public function getTemplateName()
    {
        return "home/iniciarSesion.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 24,  71 => 21,  68 => 20,  66 => 19,  63 => 18,  57 => 15,  54 => 14,  52 => 13,  47 => 10,  44 => 9,  39 => 6,  36 => 5,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block title %}Iniciar Sesión{% endblock %}

{% block css_adicional %}
    <link rel=\"stylesheet\" href=\"css/home/iniciarSesion.css\">
{% endblock %}

{% block content %}

    <form class=\"form-signin\" action=\"/iniciarsesion_action\" method=\"post\">
        <h2 class=\"form-signin-heading\">Acceso al Sitio Web</h2>
        {% if flash.message('error')[0] is defined %}
            <div class=\"alert alert-danger\" role=\"alert\">
                <strong>Atención!</strong> {{ flash.message('error')[0] }}
            </div>
        {% endif %}

        {% if flash.message('exito')[0] is defined %}
            <div class=\"alert alert-success\" role=\"alert\">
                <strong>Atención!</strong> {{ flash.message('exito')[0] }}
            </div>
        {% endif %}

        <label for=\"inputEmail\" class=\"sr-only\">Correo Electrónico</label>
        <input name=\"email\" maxlength=\"30\" minlength=\"3\" type=\"text\" id=\"inputEmail\" class=\"form-control\" placeholder=\"Correo Electrónico\" required autofocus>

        <label for=\"inputPassword\" class=\"sr-only\">Password</label>
        <input name =\"password\" maxlength=\"10\" minlength=\"3\" type=\"password\" id=\"inputPassword\" class=\"form-control\" placeholder=\"Password\" required>

        <input class=\"btn btn-primary btn-sm btn-block\" name=\"acceder\" type=\"submit\" value=\"Iniciar Sesión\">
        <input class=\"btn btn-secondary btn-sm btn-block\" name=\"registrarse\" type=\"submit\" value=\"Registrarse\" onclick=\"location.href = '/registrarse_show';\">
        <input class=\"btn btn-info btn-sm btn-block\" name=\"olvido_password\" type=\"submit\" value=\"Recuperar Password\" onclick=\"location.href = '/olvidopassword_show';\">
    </form>
{% endblock %}


", "home/iniciarSesion.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\home\\iniciarSesion.twig");
    }
}
