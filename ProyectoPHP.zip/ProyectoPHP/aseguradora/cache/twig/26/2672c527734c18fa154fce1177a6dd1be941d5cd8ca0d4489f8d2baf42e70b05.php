<?php

/* usuario/incidente.twig */
class __TwigTemplate_a107693de43e203ba42f4e2fce0cda116ccc11d7e5aa959ef18ea13475c995c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "usuario/incidente.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css_adicional' => array($this, 'block_css_adicional'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Iniciar Sesión";
    }

    // line 5
    public function block_css_adicional($context, array $blocks = array())
    {
        // line 6
        echo "    <link rel=\"stylesheet\" href=\"css/usuario/incidente.css\">
";
    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        // line 10
        echo "


    ";
        // line 13
        $this->loadTemplate("helper/headerPrivado.twig", "usuario/incidente.twig", 13)->display($context);
        // line 14
        echo "    <!-- Jumbotron -->




    ";
        // line 19
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method", false, true), 0, array(), "array", true, true)) {
            // line 20
            echo "        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> ";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 24
        echo "
    ";
        // line 25
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method", false, true), 0, array(), "array", true, true)) {
            // line 26
            echo "        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Atención!</strong> ";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 30
        echo "


    <!-- Example row of columns -->
    <div class=\"row\">

        <div class=\"col-md-6 offset-md-3\">

            <form class=\"\" action=\"/usuario/incidente_action\" method=\"post\">
                <div class=\"form-group\">
                    <label for=\"email\"><u>Tipo Incidente:</u></label>
                    <select class=\"form-control\" name=\"tipo_incidente\">
                        ";
        // line 42
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tiposIncidentes"]) ? $context["tiposIncidentes"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["tiposIncidente"]) {
            // line 43
            echo "                                <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tiposIncidente"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tiposIncidente"], "nombre", array()));
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tiposIncidente'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "                    </select>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Situación o Motivo por el cual se produjo el incidente:</u></label>
                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\" required rows=\"3\" name=\"motivo_incidente\"></textarea>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Fecha Incidente:</u></label>
                    <div id=\"sandbox-container\">
                        <input type=\"text\" type=\"text\" name=\"fecha_incidente\" class=\"form-control\" />
                    </div>

                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Cantidad de Objetos a Idemnizar:</u></label>
                    <input class=\"form-control\" type=\"number\" name=\"cantidad_objeto\" min=\"1\" max=\"50\" value=\"1\" required id=\"example-number-input\">
                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Descripción de cada objeto a idemnizar:</u> Utilize el formato
                        Nombre Objeto / cantidad Objeto / Descripción del incidente sobre objeto</label>


                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\" required rows=\"3\" name=\"descripcion_objetos\"></textarea>
                </div>


                </br>
                <button type=\"submit\" class=\"btn btn-warning\">Registrar Incidente</button>
            </form>




        </div>

    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

";
    }

    public function getTemplateName()
    {
        return "usuario/incidente.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 45,  104 => 43,  100 => 42,  86 => 30,  80 => 27,  77 => 26,  75 => 25,  72 => 24,  66 => 21,  63 => 20,  61 => 19,  54 => 14,  52 => 13,  47 => 10,  44 => 9,  39 => 6,  36 => 5,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block title %}Iniciar Sesión{% endblock %}

{% block css_adicional %}
    <link rel=\"stylesheet\" href=\"css/usuario/incidente.css\">
{% endblock %}

{% block content %}



    {% include 'helper/headerPrivado.twig' %}
    <!-- Jumbotron -->




    {% if flash.message('error')[0] is defined %}
        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> {{ flash.message('error')[0] }}
        </div>
    {% endif %}

    {% if flash.message('exito')[0] is defined %}
        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Atención!</strong> {{ flash.message('exito')[0] }}
        </div>
    {% endif %}



    <!-- Example row of columns -->
    <div class=\"row\">

        <div class=\"col-md-6 offset-md-3\">

            <form class=\"\" action=\"/usuario/incidente_action\" method=\"post\">
                <div class=\"form-group\">
                    <label for=\"email\"><u>Tipo Incidente:</u></label>
                    <select class=\"form-control\" name=\"tipo_incidente\">
                        {% for tiposIncidente in tiposIncidentes %}
                                <option value=\"{{ tiposIncidente.id }}\">{{ tiposIncidente.nombre|e }}</option>
                        {% endfor %}
                    </select>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Situación o Motivo por el cual se produjo el incidente:</u></label>
                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\" required rows=\"3\" name=\"motivo_incidente\"></textarea>
                </div>

                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Fecha Incidente:</u></label>
                    <div id=\"sandbox-container\">
                        <input type=\"text\" type=\"text\" name=\"fecha_incidente\" class=\"form-control\" />
                    </div>

                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Cantidad de Objetos a Idemnizar:</u></label>
                    <input class=\"form-control\" type=\"number\" name=\"cantidad_objeto\" min=\"1\" max=\"50\" value=\"1\" required id=\"example-number-input\">
                </div>


                <div class=\"form-group\">
                    <label for=\"pwd\"><u>Descripción de cada objeto a idemnizar:</u> Utilize el formato
                        Nombre Objeto / cantidad Objeto / Descripción del incidente sobre objeto</label>


                    <textarea class=\"form-control\" id=\"exampleTextarea\" maxlength=\"140\" required rows=\"3\" name=\"descripcion_objetos\"></textarea>
                </div>


                </br>
                <button type=\"submit\" class=\"btn btn-warning\">Registrar Incidente</button>
            </form>




        </div>

    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

{% endblock %}
























", "usuario/incidente.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\usuario\\incidente.twig");
    }
}
