<?php

/* home/registrarse.twig */
class __TwigTemplate_1010b838b6fe11803b696fe75805782090000cd069fa86d7b400c39cbe48c94b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "home/registrarse.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css_adicional' => array($this, 'block_css_adicional'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Registrarse";
    }

    // line 5
    public function block_css_adicional($context, array $blocks = array())
    {
        // line 6
        echo "    <link rel=\"stylesheet\" href=\"css/home/registrarse.css\">
";
    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        // line 10
        echo "
    <form class=\"form-signin\" action=\"/registrarse_action\" method=\"post\">
        <h2 class=\"form-signin-heading\">Registrarse</h2>

        ";
        // line 14
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method", false, true), 0, array(), "array", true, true)) {
            // line 15
            echo "            <div class=\"alert alert-danger\" role=\"alert\">
                <strong>Atención!</strong> ";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method"), 0, array(), "array"), "html", null, true);
            echo "
            </div>
        ";
        }
        // line 19
        echo "
        ";
        // line 20
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method", false, true), 0, array(), "array", true, true)) {
            // line 21
            echo "            <div class=\"alert alert-success\" role=\"alert\">
                <strong>Atención!</strong> ";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method"), 0, array(), "array"), "html", null, true);
            echo "
            </div>
        ";
        }
        // line 25
        echo "
        <label for=\"inputcliente\" class=\"sr-only\">Número de Identificacion</label>
        <input name=\"cliente\" maxlength=\"10\" minlength=\"3\" type=\"text\" id=\"inputCliente\" class=\"form-control\"
               placeholder=\"Número de Identificacion\" required autofocus>

        <label for=\"inputcliente\" class=\"sr-only\">Documento</label>
        <input name=\"documento\" maxlength=\"10\" minlength=\"3\" type=\"text\" id=\"inputCliente\" class=\"form-control\"
               placeholder=\"Documento\" required autofocus>

        <label for=\"inputEmail\" class=\"sr-only\">Correo Electrónico</label>
        <input name=\"email\" maxlength=\"30\" minlength=\"3\" type=\"email\" id=\"inputEmail\" class=\"form-control\"
               placeholder=\"Correo Electrónico\" required>

        <label for=\"inputPassword\" class=\"sr-only\">Password</label>
        <input name=\"password\" maxlength=\"10\" minlength=\"3\" type=\"password\" id=\"inputPassword\" class=\"form-control\"
               placeholder=\"Password\" required>

        <button class=\"btn btn-primary btn-sm btn-block\" type=\"submit\">Registrar</button>

    </form>
";
    }

    public function getTemplateName()
    {
        return "home/registrarse.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 25,  72 => 22,  69 => 21,  67 => 20,  64 => 19,  58 => 16,  55 => 15,  53 => 14,  47 => 10,  44 => 9,  39 => 6,  36 => 5,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block title %}Registrarse{% endblock %}

{% block css_adicional %}
    <link rel=\"stylesheet\" href=\"css/home/registrarse.css\">
{% endblock %}

{% block content %}

    <form class=\"form-signin\" action=\"/registrarse_action\" method=\"post\">
        <h2 class=\"form-signin-heading\">Registrarse</h2>

        {% if flash.message('error')[0] is defined %}
            <div class=\"alert alert-danger\" role=\"alert\">
                <strong>Atención!</strong> {{ flash.message('error')[0] }}
            </div>
        {% endif %}

        {% if flash.message('exito')[0] is defined %}
            <div class=\"alert alert-success\" role=\"alert\">
                <strong>Atención!</strong> {{ flash.message('exito')[0] }}
            </div>
        {% endif %}

        <label for=\"inputcliente\" class=\"sr-only\">Número de Identificacion</label>
        <input name=\"cliente\" maxlength=\"10\" minlength=\"3\" type=\"text\" id=\"inputCliente\" class=\"form-control\"
               placeholder=\"Número de Identificacion\" required autofocus>

        <label for=\"inputcliente\" class=\"sr-only\">Documento</label>
        <input name=\"documento\" maxlength=\"10\" minlength=\"3\" type=\"text\" id=\"inputCliente\" class=\"form-control\"
               placeholder=\"Documento\" required autofocus>

        <label for=\"inputEmail\" class=\"sr-only\">Correo Electrónico</label>
        <input name=\"email\" maxlength=\"30\" minlength=\"3\" type=\"email\" id=\"inputEmail\" class=\"form-control\"
               placeholder=\"Correo Electrónico\" required>

        <label for=\"inputPassword\" class=\"sr-only\">Password</label>
        <input name=\"password\" maxlength=\"10\" minlength=\"3\" type=\"password\" id=\"inputPassword\" class=\"form-control\"
               placeholder=\"Password\" required>

        <button class=\"btn btn-primary btn-sm btn-block\" type=\"submit\">Registrar</button>

    </form>
{% endblock %}

", "home/registrarse.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\home\\registrarse.twig");
    }
}
