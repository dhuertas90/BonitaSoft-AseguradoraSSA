<?php

/* helper/headerPrivadoEmpleado.twig */
class __TwigTemplate_37979178d8bcbfe5e99366a67079b4f874de7656ba24870b6ca2b0530ba6ecc8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"masthead\">
    <h3 class=\"text-muted\">Aseguradora - Empleado</h3>

    <nav class=\"navbar navbar-expand-md navbar-light bg-light rounded mb-3\">
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarCollapse\" aria-controls=\"navbarCollapse\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>
        <div class=\"collapse navbar-collapse\" id=\"navbarCollapse\">
            <ul class=\"navbar-nav text-md-center nav-justified w-100\">
                <li class=\"nav-item active\">
                    <a class=\"nav-link\" href=\"/usuario/inicio\">Home <span class=\"sr-only\">(current)</span></a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" href=\"/empleado/listado_usuarios\">Listado Usuarios Registrados</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" href=\"/empleado/listado_incidentes\">Listado Incidentes Generados</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" href=\"/cerrarsesion_action\">Cerrar Sesión</a>
                </li>


            </ul>
        </div>
    </nav>
</div>";
    }

    public function getTemplateName()
    {
        return "helper/headerPrivadoEmpleado.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"masthead\">
    <h3 class=\"text-muted\">Aseguradora - Empleado</h3>

    <nav class=\"navbar navbar-expand-md navbar-light bg-light rounded mb-3\">
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarCollapse\" aria-controls=\"navbarCollapse\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>
        <div class=\"collapse navbar-collapse\" id=\"navbarCollapse\">
            <ul class=\"navbar-nav text-md-center nav-justified w-100\">
                <li class=\"nav-item active\">
                    <a class=\"nav-link\" href=\"/usuario/inicio\">Home <span class=\"sr-only\">(current)</span></a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" href=\"/empleado/listado_usuarios\">Listado Usuarios Registrados</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" href=\"/empleado/listado_incidentes\">Listado Incidentes Generados</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" href=\"/cerrarsesion_action\">Cerrar Sesión</a>
                </li>


            </ul>
        </div>
    </nav>
</div>", "helper/headerPrivadoEmpleado.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\helper\\headerPrivadoEmpleado.twig");
    }
}
