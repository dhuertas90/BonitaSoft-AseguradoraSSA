<?php

/* empleado/listadoUsuarios.twig */
class __TwigTemplate_235d9b188156a1f62eae405cfb6869ca927c2211ad54167d3f7ed73925ce838a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "empleado/listadoUsuarios.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css_adicional' => array($this, 'block_css_adicional'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Incidente Detalle";
    }

    // line 5
    public function block_css_adicional($context, array $blocks = array())
    {
        // line 6
        echo "    <link rel=\"stylesheet\" href=\"css/empleado/listadoUsuarios.css\">
";
    }

    // line 10
    public function block_content($context, array $blocks = array())
    {
        // line 11
        echo "


    ";
        // line 14
        $this->loadTemplate("helper/headerPrivadoEmpleado.twig", "empleado/listadoUsuarios.twig", 14)->display($context);
        // line 15
        echo "

    ";
        // line 17
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method", false, true), 0, array(), "array", true, true)) {
            // line 18
            echo "        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> ";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 22
        echo "
    ";
        // line 23
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method", false, true), 0, array(), "array", true, true)) {
            // line 24
            echo "        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Exito!</strong> ";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 28
        echo "
    <!-- Example row of columns -->
    <div class=\"row\">

        <div class=\"col-md-9 offset-md-3\">




            <h2>Listado de Usuario</h2>

            <table class=\"table\">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Rol</th>
                    <th>Documento</th>
                    <th>Email</th>
                    <th>Activo</th>
                </tr>
                </thead>
                <tbody>

                ";
        // line 51
        $context["i"] = 1;
        // line 52
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listado_usuarios"]) ? $context["listado_usuarios"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["usuario"]) {
            // line 53
            echo "                    <tr class=\"table-success\">
                        <th scope=\"row\">";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "id", array()), "html", null, true);
            echo "</th>
                        <td>";
            // line 55
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["usuario"], "rol", array()), "nombre", array()));
            echo "</td>
                        <td>";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["usuario"], "persona", array()), "documento", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute($context["usuario"], "email", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 58
            echo ((($this->getAttribute($context["usuario"], "activo", array()) == 1)) ? ("Si") : ("No"));
            echo "</td>
                    </tr>
                    ";
            // line 60
            $context["i"] = ((isset($context["i"]) ? $context["i"] : null) + 1);
            // line 61
            echo "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['usuario'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 62
        echo "





                </tbody>
            </table>


        </div>

    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

";
    }

    public function getTemplateName()
    {
        return "empleado/listadoUsuarios.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 62,  141 => 61,  139 => 60,  134 => 58,  130 => 57,  126 => 56,  122 => 55,  118 => 54,  115 => 53,  110 => 52,  108 => 51,  83 => 28,  77 => 25,  74 => 24,  72 => 23,  69 => 22,  63 => 19,  60 => 18,  58 => 17,  54 => 15,  52 => 14,  47 => 11,  44 => 10,  39 => 6,  36 => 5,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block title %}Incidente Detalle{% endblock %}

{% block css_adicional %}
    <link rel=\"stylesheet\" href=\"css/empleado/listadoUsuarios.css\">
{% endblock %}


{% block content %}



    {% include 'helper/headerPrivadoEmpleado.twig' %}


    {% if flash.message('error')[0] is defined %}
        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> {{ flash.message('error')[0] }}
        </div>
    {% endif %}

    {% if flash.message('exito')[0] is defined %}
        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Exito!</strong> {{ flash.message('exito')[0] }}
        </div>
    {% endif %}

    <!-- Example row of columns -->
    <div class=\"row\">

        <div class=\"col-md-9 offset-md-3\">




            <h2>Listado de Usuario</h2>

            <table class=\"table\">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Rol</th>
                    <th>Documento</th>
                    <th>Email</th>
                    <th>Activo</th>
                </tr>
                </thead>
                <tbody>

                {% set i = 1%}
                {% for usuario in listado_usuarios %}
                    <tr class=\"table-success\">
                        <th scope=\"row\">{{ usuario.id }}</th>
                        <td>{{ usuario.rol.nombre|e }}</td>
                        <td>{{ usuario.persona.documento }}</td>
                        <td>{{ usuario.email }}</td>
                        <td>{{ (usuario.activo == 1) ? 'Si':'No' }}</td>
                    </tr>
                    {%set i = i + 1%}
                {% endfor %}






                </tbody>
            </table>


        </div>

    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

{% endblock %}
























", "empleado/listadoUsuarios.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\empleado\\listadoUsuarios.twig");
    }
}
