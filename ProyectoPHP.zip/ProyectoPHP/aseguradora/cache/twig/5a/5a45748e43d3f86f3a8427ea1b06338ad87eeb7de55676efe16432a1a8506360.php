<?php

/* empleado/listadoIncidentes.twig */
class __TwigTemplate_82e1323b2fa053794ded90c4b80cc753254d7175ab4f6ba1784be0820ec76f8e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "empleado/listadoIncidentes.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css_adicional' => array($this, 'block_css_adicional'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Incidente Detalle";
    }

    // line 5
    public function block_css_adicional($context, array $blocks = array())
    {
        // line 6
        echo "    <link rel=\"stylesheet\" href=\"css/empleado/listadoIncidentes.css\">
";
    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
        // line 12
        echo "


    ";
        // line 15
        $this->loadTemplate("helper/headerPrivadoEmpleado.twig", "empleado/listadoIncidentes.twig", 15)->display($context);
        // line 16
        echo "

    ";
        // line 18
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method", false, true), 0, array(), "array", true, true)) {
            // line 19
            echo "        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> ";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "error"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 23
        echo "
    ";
        // line 24
        if ($this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method", false, true), 0, array(), "array", true, true)) {
            // line 25
            echo "        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Exito!</strong> ";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "message", array(0 => "exito"), "method"), 0, array(), "array"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 29
        echo "
    <!-- Example row of columns -->
    <div class=\"row\">
        <div class=\"col-md-9 offset-md-3\">
            <h2>Incidentes Cargados</h2>
            <table class=\"table\">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Documento</th>
                    <th>Tipo</th>
                    <th>Fecha Carga</th>
                    <th>Fecha Incidente</th>
                    <th>Estado</th>
                    <th>Acción</th>
                </tr>
                </thead>
                <tbody>
                ";
        // line 47
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listado_incidentes"]) ? $context["listado_incidentes"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["incidente"]) {
            // line 48
            echo "                    <tr class=\"table-success\">
                        <th scope=\"row\">";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute($context["incidente"], "id", array()), "html", null, true);
            echo "</th>
                        <td>";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["incidente"], "usuario", array()), "persona", array()), "documento", array()));
            echo "</td>
                        <td>";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["incidente"], "tipo", array()), "nombre", array()));
            echo "</td>
                        <td>";
            // line 52
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["incidente"], "fechaCarga", array()), "d-m-Y"), "html", null, true);
            echo "</td>
                        <td>";
            // line 53
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["incidente"], "fechaIncidente", array()), "d-m-Y"), "html", null, true);
            echo "</td>
                        <td>";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["incidente"], "estado", array()), "nombre", array()));
            echo "</td>
                        <td> <a href=\"";
            // line 55
            echo twig_escape_filter($this->env, ("/empleado/incidente_detalle/" . $this->getAttribute($context["incidente"], "id", array())), "html", null, true);
            echo "\">Visualizar Detalles Incidente</a></td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['incidente'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "                </tbody>
            </table>
        </div>
    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

";
    }

    public function getTemplateName()
    {
        return "empleado/listadoIncidentes.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 58,  134 => 55,  130 => 54,  126 => 53,  122 => 52,  118 => 51,  114 => 50,  110 => 49,  107 => 48,  103 => 47,  83 => 29,  77 => 26,  74 => 25,  72 => 24,  69 => 23,  63 => 20,  60 => 19,  58 => 18,  54 => 16,  52 => 15,  47 => 12,  44 => 11,  39 => 6,  36 => 5,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block title %}Incidente Detalle{% endblock %}

{% block css_adicional %}
    <link rel=\"stylesheet\" href=\"css/empleado/listadoIncidentes.css\">
{% endblock %}



{% block content %}



    {% include 'helper/headerPrivadoEmpleado.twig' %}


    {% if flash.message('error')[0] is defined %}
        <div class=\"alert alert-danger\" role=\"alert\">
            <strong>Atención!</strong> {{ flash.message('error')[0] }}
        </div>
    {% endif %}

    {% if flash.message('exito')[0] is defined %}
        <div class=\"alert alert-success\" role=\"alert\">
            <strong>Exito!</strong> {{ flash.message('exito')[0] }}
        </div>
    {% endif %}

    <!-- Example row of columns -->
    <div class=\"row\">
        <div class=\"col-md-9 offset-md-3\">
            <h2>Incidentes Cargados</h2>
            <table class=\"table\">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Documento</th>
                    <th>Tipo</th>
                    <th>Fecha Carga</th>
                    <th>Fecha Incidente</th>
                    <th>Estado</th>
                    <th>Acción</th>
                </tr>
                </thead>
                <tbody>
                {% for incidente in listado_incidentes %}
                    <tr class=\"table-success\">
                        <th scope=\"row\">{{ incidente.id }}</th>
                        <td>{{ incidente.usuario.persona.documento|e }}</td>
                        <td>{{ incidente.tipo.nombre|e }}</td>
                        <td>{{ incidente.fechaCarga|date('d-m-Y') }}</td>
                        <td>{{ incidente.fechaIncidente|date('d-m-Y') }}</td>
                        <td>{{ incidente.estado.nombre|e }}</td>
                        <td> <a href=\"{{ ('/empleado/incidente_detalle/' ~ incidente.id)}}\">Visualizar Detalles Incidente</a></td>
                    </tr>
                {% endfor %}
                </tbody>
            </table>
        </div>
    </div>


    <!-- Site footer -->
    <footer class=\"footer\">
        <p></p>
    </footer>

{% endblock %}
























", "empleado/listadoIncidentes.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\empleado\\listadoIncidentes.twig");
    }
}
