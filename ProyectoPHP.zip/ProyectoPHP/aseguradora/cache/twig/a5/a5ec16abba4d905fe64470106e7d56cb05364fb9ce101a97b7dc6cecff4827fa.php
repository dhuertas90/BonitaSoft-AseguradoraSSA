<?php

/* restapi/test_upload_dropbox.twig */
class __TwigTemplate_dc808a5e1a5673c2be32e15f9703858e7e4bf8f1fe4839a7c665f7b1c3b5610c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html>
<head>
    <title>Dropbox JavaScript SDK</title>

    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/dropbox.js/2.5.2/Dropbox-sdk.min.js\"></script>

</head>
<body>
<!-- Example layout boilerplate -->
<header class=\"page-header\">
    <div class=\"container\">
        <nav>
            <a href=\"/\">
                <h1>
                    <img src=\"https://cfl.dropboxstatic.com/static/images/brand/logotype_white-vflRG5Zd8.svg\" class=\"logo\" />
                    JavaScript SDK Examples
                </h1>
            </a>
            <a href=\"https://github.com/dropbox/dropbox-sdk-js/tree/master/examples/javascript\" class=\"view-source\">View Source</a>
        </nav>
        <h2 class=\"code\">
            <a href=\"/\">examples</a> / upload file
        </h2>
    </div>
</header>

<!-- Example description and UI -->
<section class=\"container main\">
    <p>This example shows how to use the <code>Dropbox.filesUpload()</code> [<a href=\"http://dropbox.github.io/dropbox-sdk-js/Dropbox.html#filesUpload\">docs</a>] method to upload a file.</p>

    <form onSubmit=\"return uploadFile()\">
        <input type=\"text\" id=\"access-token\" placeholder=\"Access token\" value=\"lNTO4-ymxIsAAAAAAADhUW67CVrkjcgXu_2ERWCGtqpKRDsfqn8rbLuCMeNaPB8_\" />
        <input type=\"file\" id=\"file-upload\" />
        <button type=\"submit\">Submit</button>
    </form>

    <!-- A place to show the status of the upload -->
    <h2 id=\"results\"></h2>

    <p class=\"info\">To obtain an access token for quick testing, you can go to <a href=\"https://dropbox.github.io/dropbox-api-v2-explorer/#files_list_folder\" target=\"_blank\">API Explorer</a> click the \"Get Token\" button on the top right, copy the token it creates and then paste it here.</p>
</section>

<script>
    function uploadFile() {
        var ACCESS_TOKEN = document.getElementById('access-token').value;
        var dbx = new Dropbox({ accessToken: ACCESS_TOKEN });
        var fileInput = document.getElementById('file-upload');
        var file = fileInput.files[0];
        dbx.filesUpload({path: '/' + file.name, contents: file})
            .then(function(response) {
                var results = document.getElementById('results');
                results.appendChild(document.createTextNode('File uploaded!'));
                console.log(response);
            })
            .catch(function(error) {
                console.error(error);
            });
        return false;
    }
</script>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "restapi/test_upload_dropbox.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!doctype html>
<html>
<head>
    <title>Dropbox JavaScript SDK</title>

    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/dropbox.js/2.5.2/Dropbox-sdk.min.js\"></script>

</head>
<body>
<!-- Example layout boilerplate -->
<header class=\"page-header\">
    <div class=\"container\">
        <nav>
            <a href=\"/\">
                <h1>
                    <img src=\"https://cfl.dropboxstatic.com/static/images/brand/logotype_white-vflRG5Zd8.svg\" class=\"logo\" />
                    JavaScript SDK Examples
                </h1>
            </a>
            <a href=\"https://github.com/dropbox/dropbox-sdk-js/tree/master/examples/javascript\" class=\"view-source\">View Source</a>
        </nav>
        <h2 class=\"code\">
            <a href=\"/\">examples</a> / upload file
        </h2>
    </div>
</header>

<!-- Example description and UI -->
<section class=\"container main\">
    <p>This example shows how to use the <code>Dropbox.filesUpload()</code> [<a href=\"http://dropbox.github.io/dropbox-sdk-js/Dropbox.html#filesUpload\">docs</a>] method to upload a file.</p>

    <form onSubmit=\"return uploadFile()\">
        <input type=\"text\" id=\"access-token\" placeholder=\"Access token\" value=\"lNTO4-ymxIsAAAAAAADhUW67CVrkjcgXu_2ERWCGtqpKRDsfqn8rbLuCMeNaPB8_\" />
        <input type=\"file\" id=\"file-upload\" />
        <button type=\"submit\">Submit</button>
    </form>

    <!-- A place to show the status of the upload -->
    <h2 id=\"results\"></h2>

    <p class=\"info\">To obtain an access token for quick testing, you can go to <a href=\"https://dropbox.github.io/dropbox-api-v2-explorer/#files_list_folder\" target=\"_blank\">API Explorer</a> click the \"Get Token\" button on the top right, copy the token it creates and then paste it here.</p>
</section>

<script>
    function uploadFile() {
        var ACCESS_TOKEN = document.getElementById('access-token').value;
        var dbx = new Dropbox({ accessToken: ACCESS_TOKEN });
        var fileInput = document.getElementById('file-upload');
        var file = fileInput.files[0];
        dbx.filesUpload({path: '/' + file.name, contents: file})
            .then(function(response) {
                var results = document.getElementById('results');
                results.appendChild(document.createTextNode('File uploaded!'));
                console.log(response);
            })
            .catch(function(error) {
                console.error(error);
            });
        return false;
    }
</script>
</body>
</html>
", "restapi/test_upload_dropbox.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\restapi\\test_upload_dropbox.twig");
    }
}
