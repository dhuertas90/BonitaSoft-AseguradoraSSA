<?php

/* restapi/test_upload_dropbox_ws.twig */
class __TwigTemplate_419082fe227cd801e98e65435ba960204c9dec10641fad7d3bde94d5c84aa36c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html>
<head>
    <title>Dropbox JavaScript SDK</title>

    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/dropbox.js/2.5.2/Dropbox-sdk.min.js\"></script>

    <script
            src=\"https://code.jquery.com/jquery-3.2.1.js\"
            integrity=\"sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE=\"
            crossorigin=\"anonymous\"></script>


</head>
<body>
<!-- Example layout boilerplate -->

<!-- Example description and UI -->
<section class=\"container main\">
    <form id=\"request\">
        <input type=\"text\" name =\"sample001\" id=\"sample001\" value=\"sample001\" />
        <input type=\"text\" name=\"token\" id=\"access-token\" value=\"\" />
        <input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\" multiple/>
        <button type=\"submit\" name=\"submit\">Submit</button>
    </form>

    <!-- A place to show the status of the upload -->
    <h2 id=\"results\"></h2>



</section>

<script>
    \$(function(){



        \$(\"#request\").on(\"submit\", function(e){

            /*
            e.preventDefault();
            var form_data = new FormData(this);

            \$.ajax({
                type: 'post',
                url: 'http://localhost:81/api/samplepostdropbox',
                data: form_data,
                cache: false,
                contentType: false,
                processData: false,
                success: function (result) {
                    console.log(result);
                },
                error: function () {
                    console.log(\"error\");
                }
            })
             */


            var fileInput = document.getElementById('fileToUpload');
            var file = fileInput.files[0];

            var \$form    = \$(e.target),
                formData = new FormData(),
                params   = \$form.serializeArray(),
                files    = \$form.find('[name=\"fileToUpload\"]')[0].files;

            console.log('object evt1: %O', \$form);

            \$.each(files, function(i, file) {
                // Prefix the name of uploaded files with \"uploadedFiles-\"
                // Of course, you can change it to any string
                console.log(\"Itero File\");
                formData.append('uploadedFiles-' + i, file);
            });

           // formData.append('formulario', \$form.serialize());

            \$.each(params, function(i, val) {
                console.log(\"Itero Param\");
                formData.append(val.name, val.value);
            });

            \$.ajax({
                url: 'https://secret-cove-11372.herokuapp.com/api/samplepostdropboxjs',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                type: 'POST',
                success: function (result) {
                    console.log(result);
                },
                error: function () {
                    console.log(\"error\");
                }});




            e.preventDefault();
        });
    });


</script>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "restapi/test_upload_dropbox_ws.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!doctype html>
<html>
<head>
    <title>Dropbox JavaScript SDK</title>

    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/dropbox.js/2.5.2/Dropbox-sdk.min.js\"></script>

    <script
            src=\"https://code.jquery.com/jquery-3.2.1.js\"
            integrity=\"sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE=\"
            crossorigin=\"anonymous\"></script>


</head>
<body>
<!-- Example layout boilerplate -->

<!-- Example description and UI -->
<section class=\"container main\">
    <form id=\"request\">
        <input type=\"text\" name =\"sample001\" id=\"sample001\" value=\"sample001\" />
        <input type=\"text\" name=\"token\" id=\"access-token\" value=\"\" />
        <input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\" multiple/>
        <button type=\"submit\" name=\"submit\">Submit</button>
    </form>

    <!-- A place to show the status of the upload -->
    <h2 id=\"results\"></h2>



</section>

<script>
    \$(function(){



        \$(\"#request\").on(\"submit\", function(e){

            /*
            e.preventDefault();
            var form_data = new FormData(this);

            \$.ajax({
                type: 'post',
                url: 'http://localhost:81/api/samplepostdropbox',
                data: form_data,
                cache: false,
                contentType: false,
                processData: false,
                success: function (result) {
                    console.log(result);
                },
                error: function () {
                    console.log(\"error\");
                }
            })
             */


            var fileInput = document.getElementById('fileToUpload');
            var file = fileInput.files[0];

            var \$form    = \$(e.target),
                formData = new FormData(),
                params   = \$form.serializeArray(),
                files    = \$form.find('[name=\"fileToUpload\"]')[0].files;

            console.log('object evt1: %O', \$form);

            \$.each(files, function(i, file) {
                // Prefix the name of uploaded files with \"uploadedFiles-\"
                // Of course, you can change it to any string
                console.log(\"Itero File\");
                formData.append('uploadedFiles-' + i, file);
            });

           // formData.append('formulario', \$form.serialize());

            \$.each(params, function(i, val) {
                console.log(\"Itero Param\");
                formData.append(val.name, val.value);
            });

            \$.ajax({
                url: 'https://secret-cove-11372.herokuapp.com/api/samplepostdropboxjs',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                type: 'POST',
                success: function (result) {
                    console.log(result);
                },
                error: function () {
                    console.log(\"error\");
                }});




            e.preventDefault();
        });
    });


</script>
</body>
</html>
", "restapi/test_upload_dropbox_ws.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\restapi\\test_upload_dropbox_ws.twig");
    }
}
