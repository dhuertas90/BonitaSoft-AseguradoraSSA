<?php

/* base.html.twig */
class __TwigTemplate_9ba85e1e5bdf44c295b4c2aae4538ea69a875d7b9de159a52f282dcf767566fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'css_adicional' => array($this, 'block_css_adicional'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
<head>
    <meta charset=\"utf-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">

    <title>Aplicación Web - ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo " </title>

    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css\">
    <script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js\" ></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js\" ></script>


    <link id=\"\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.0/css/bootstrap-datepicker.css\" rel=\"stylesheet\">
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.0/js/bootstrap-datepicker.js\"></script>


    <script type=\"text/javascript\">
        \$(document).ready(function() {
            \$(\".add-more\").click(function(){
                var html = \$(\".copy\").html();
                \$(\".after-add-more\").after(html);
            });

            \$(\"body\").on(\"click\",\".remove\",function(){
                \$(this).parents(\".control-group\").remove();
            });


            \$('#sandbox-container input').datepicker({
                autoclose: true,
                startDate: '-2m',
                endDate: '-1d'
            });

        });

    </script>


    ";
        // line 41
        $this->displayBlock('css_adicional', $context, $blocks);
        // line 43
        echo "
</head>
    <body>
        <div class=\"container\">
            ";
        // line 47
        $this->displayBlock('content', $context, $blocks);
        // line 49
        echo "        </div>
    </body>
</html>

";
    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
    }

    // line 41
    public function block_css_adicional($context, array $blocks = array())
    {
        // line 42
        echo "    ";
    }

    // line 47
    public function block_content($context, array $blocks = array())
    {
        // line 48
        echo "            ";
    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  100 => 48,  97 => 47,  93 => 42,  90 => 41,  85 => 6,  77 => 49,  75 => 47,  69 => 43,  67 => 41,  29 => 6,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<html>
<head>
    <meta charset=\"utf-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">

    <title>Aplicación Web - {% block title %}{% endblock %} </title>

    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css\">
    <script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js\" ></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js\" ></script>


    <link id=\"\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.0/css/bootstrap-datepicker.css\" rel=\"stylesheet\">
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.0/js/bootstrap-datepicker.js\"></script>


    <script type=\"text/javascript\">
        \$(document).ready(function() {
            \$(\".add-more\").click(function(){
                var html = \$(\".copy\").html();
                \$(\".after-add-more\").after(html);
            });

            \$(\"body\").on(\"click\",\".remove\",function(){
                \$(this).parents(\".control-group\").remove();
            });


            \$('#sandbox-container input').datepicker({
                autoclose: true,
                startDate: '-2m',
                endDate: '-1d'
            });

        });

    </script>


    {% block css_adicional %}
    {% endblock %}

</head>
    <body>
        <div class=\"container\">
            {% block content %}
            {% endblock %}
        </div>
    </body>
</html>

", "base.html.twig", "C:\\Apache24\\htdocs\\ddsd_2017\\app\\templates\\base.html.twig");
    }
}
