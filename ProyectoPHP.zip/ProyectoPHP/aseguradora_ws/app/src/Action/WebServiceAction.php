<?php
namespace App\Action;

use Psr\Log\LoggerInterface;
use Kunnu\Dropbox\DropboxApp;
use Kunnu\Dropbox\Dropbox;

final class WebServiceAction
{
    private $logger;

    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    private function verificarErroresImagenes($imagenes){
        foreach ($imagenes as $imagen) {
            $tiposImagenes = array("image/jpeg");
            if ($_FILES[$imagen]['tmp_name']) {
                if ((($_FILES[$imagen]['size'] > 2097152) || (!in_array($_FILES[$imagen]['type'],$tiposImagenes)) )){
                    return 1;
                }
            }
        }
    }

    public function dropboxGetThumbnails($request, $response, $args)
    {
        header('Access-Control-Allow-Origin: *');

        if (!isset($_POST["token"]) || empty($_POST["token"])) {
            return $response->withJSON("Falta valor token",400);
        }
        if (!isset($_POST["clientid"]) || empty($_POST["clientid"]) || !isset($_POST["clientid"]) || empty($_POST["clientid"])) {
            return $response->withJSON("Falta valor ClientId o ClientSecret Dropbox",400);
        }
        $token = $_POST["token"];
        $clientId = $_POST["clientid"];
        $clientSecret = $_POST["clientsecret"];

        try {
            $app = new DropboxApp($clientId, $clientSecret, $token);
            $dropbox = new Dropbox($app);
        } catch (\Exception $e) {
            return $response->withJSON("Error al configurar Dropbox",500);
        }

        if (!isset($_POST["expediente"]) || empty($_POST["expediente"])) {
            return $response->withJSON("Falta numero de expediente",400);
        }
        $expediente = $_POST["expediente"];

        $directorioFoto = "/expediente_$expediente";
        $imagenes = array("image1.jpg","image2.jpg","image3.jpg","image4.jpg");
        $arregloThumbs = array("","","","");

        $folderExiste = 0;
        try{
            $dropbox->search($directorioFoto, "", ['start' => 0, 'max_results' => 5]);
            $folderExiste = 1;
        } catch (\Exception $e) {

        }

        if($folderExiste)
        {
            try{

                for ($x = 0; $x < 4; $x++) {
                    $foto = $imagenes[$x];

                    $buscoFoto = $dropbox->search($directorioFoto, $foto, ['start' => 0, 'max_results' => 5]);
                    if($buscoFoto->getItems()->first())
                    {
                        $temporaryLink = $dropbox->getTemporaryLink($directorioFoto."/".$foto);
                        $enlace = $temporaryLink->getLink();
                        $this->logger->info("El enlace es". $enlace);
                        $arregloThumbs[$x] = $enlace;
                    }
                }

            } catch (\Exception $e) {
                $this->logger->info("Excepcion al objetenes las imagenes".print_r($e,true));
                return $response->withJSON("Error al procesar las imagenes",500);
            }
        }



        return $response->withJSON($arregloThumbs, 200);
    }


    /*
     * validad q no exista
     * */
    public function dropboxUpload($request, $response, $args)
    {

        header('Access-Control-Allow-Origin: *');

        if (!isset($_POST["token"]) || empty($_POST["token"])) {
            return $response->withJSON("Falta valor token",400);
        }
        if (!isset($_POST["clientid"]) || empty($_POST["clientid"]) || !isset($_POST["clientid"]) || empty($_POST["clientid"])) {
            return $response->withJSON("Falta valor ClientId o ClientSecret Dropbox",400);
        }
        $token = $_POST["token"];
        $clientId = $_POST["clientid"];
        $clientSecret = $_POST["clientsecret"];

        try {
            $app = new DropboxApp($clientId, $clientSecret, $token);
            $dropbox = new Dropbox($app);
        } catch (\Exception $e) {
            return $response->withJSON("Error al configurar Dropbox",500);
        }

        if (!isset($_POST["vp_numeroExpediente"]) || empty($_POST["vp_numeroExpediente"])) {
            return $response->withJSON("Falta numero de expediente",400);
        }


        $imagenes = array("image1","image2","image3","image4");
        if($this->verificarErroresImagenes($imagenes))
        {
            return $response->withJSON("Imagenes no cumplen condiciones. JPG Menor a 2Mb",400);
        }

        try {

            $expediente = $_POST["vp_numeroExpediente"];

            $directorioFoto = "/expediente_$expediente";

            $buscoDirectorio = $dropbox->search("/", "expediente_$expediente", ['start' => 0, 'max_results' => 5]);
            if(!$buscoDirectorio->getItems()->first())
            {
                $dropbox->createFolder($directorioFoto);
            }



            //Imagen1
            $buscoFoto1 = $dropbox->search("$directorioFoto", "image1.jpg", ['start' => 0, 'max_results' => 5]);
            $existeImage1 = 0;
            if($buscoFoto1->getItems()->first())
            {
                //$dropbox->delete("$directorioFoto/image1.jpg");

                $file = $dropbox->getMetadata("$directorioFoto/image1.jpg");
                $revision = $file->getRev();
                $params = [
                    'mode' => [
                        ".tag" => "update",
                        'update' => $revision
                    ],
                    'autorename' => false
                ];
                $existeImage1 = 1;


            }
            if (($_FILES['image1']['tmp_name'])){

                if($existeImage1)
                {
                    $dropbox->upload($_FILES['image1']['tmp_name'], "$directorioFoto/image1.jpg", $params);
                }else{
                    $dropbox->simpleUpload($_FILES['image1']['tmp_name'], "$directorioFoto/image1.jpg", ['autorename' => false]);
                }


            }

            //Imagen2
            $buscoFoto2 = $dropbox->search("$directorioFoto", "image2.jpg", ['start' => 0, 'max_results' => 5]);
            $existeImage2 = 0;
            if($buscoFoto2->getItems()->first())
            {
                //$dropbox->delete("$directorioFoto/image2.jpg");
                $file = $dropbox->getMetadata("$directorioFoto/image2.jpg");
                $revision = $file->getRev();
                $params = [
                    'mode' => [
                        ".tag" => "update",
                        'update' => $revision
                    ],
                    'autorename' => false
                ];
                $existeImage2 = 1;

            }
            if ($_FILES['image2']['tmp_name']){
                if($existeImage2)
                {
                    $dropbox->upload($_FILES['image2']['tmp_name'], "$directorioFoto/image2.jpg", $params);
                }else{
                    $dropbox->simpleUpload($_FILES['image2']['tmp_name'], "$directorioFoto/image2.jpg", ['autorename' => false]);
                }

            }

            //Imagen3
            $existeImage3 = 0;
            $buscoFoto3 = $dropbox->search("$directorioFoto", "image3.jpg", ['start' => 0, 'max_results' => 5]);
            if($buscoFoto3->getItems()->first())
            {
                //$dropbox->delete("$directorioFoto/image3.jpg");
                $file = $dropbox->getMetadata("$directorioFoto/image3.jpg");
                $revision = $file->getRev();
                $params = [
                    'mode' => [
                        ".tag" => "update",
                        'update' => $revision
                    ],
                    'autorename' => false
                ];
                $existeImage3 = 1;

            }
            if ($_FILES['image3']['tmp_name']){

                if($existeImage3)
                {
                    $dropbox->upload($_FILES['image3']['tmp_name'], "$directorioFoto/image3.jpg", $params);
                }else{
                    $dropbox->simpleUpload($_FILES['image3']['tmp_name'], "$directorioFoto/image3.jpg", ['autorename' => false]);
                }

            }

            $buscoFoto4 = $dropbox->search("$directorioFoto", "image4.jpg", ['start' => 0, 'max_results' => 5]);
            $existeImage4 = 0;
            if($buscoFoto4->getItems()->first())
            {
                //$dropbox->delete("$directorioFoto/image4.jpg");
                $file = $dropbox->getMetadata("$directorioFoto/image4.jpg");
                $revision = $file->getRev();
                $params = [
                    'mode' => [
                        ".tag" => "update",
                        'update' => $revision
                    ],
                    'autorename' => false
                ];
                $existeImage4 = 1;

            }
            if ($_FILES['image4']['tmp_name']){

                if($existeImage4)
                {
                    $dropbox->upload($_FILES['image4']['tmp_name'], "$directorioFoto/image4.jpg", $params);
                }else{
                    $dropbox->simpleUpload($_FILES['image4']['tmp_name'], "$directorioFoto/image4.jpg", ['autorename' => false]);
                }

            }

            return $response->withJSON("Archivos Subidos", 200);

        } catch (\Exception $e) {
            return $response->withJSON("Error al subir imagen",500);
        }

    }

}
