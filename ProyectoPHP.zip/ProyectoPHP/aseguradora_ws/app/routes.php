<?php

$app->post('/api/dropbox_get_thumbnails', 'App\Action\WebServiceAction:dropboxGetThumbnails');

$app->post('/api/dropbox_upload', 'App\Action\WebServiceAction:dropboxUpload');

$app->post('/api/clear_folder', 'App\Action\WebServiceAction:dropboxClearFolder');
