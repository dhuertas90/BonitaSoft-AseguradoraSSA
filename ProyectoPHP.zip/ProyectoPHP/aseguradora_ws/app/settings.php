<?php
return [
    'settings' => [
        'logger' => [
            'name' => 'app',
            'path' => __DIR__ . '/../log/app.log',
        ]
    ],
];
