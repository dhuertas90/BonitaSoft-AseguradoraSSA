<?php

namespace Monitor;

require '../includes/config.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'layout/defaultHead.php'; ?>

</head>

<body>

<!--
    Indicador 1
    Indicador que muestre el promedio de casos que finalizan con un resultado favorable para el beneficiario del incidente.
-->
<?php
$cases = 0;
$response = Cases::getArchivedCases();
if ($response['success']) {
    $cases = $response['data'];
    $countCases = count($cases);
}
?>

<?php
$gsent = $pdo->prepare("SELECT count(*) FROM incidentes WHERE estado_id = (SELECT id FROM estado_incidente WHERE nombre = \"APROBADO\")");
$gsent->execute();
$finalizados = $gsent->fetchColumn();
$finalizados>0?$finalizados:0;
?>

<!--  Indicador 2 -->
<?php
$casosArchivadosMes = array();
$sumatoriaArchivadosMes = 0;
foreach ($cases as &$valor) {
    $valor = $valor->end_date;
    $parsed_date = date_parse_from_format('Ym', $valor);
    $indexDate = $parsed_date['year'] . $parsed_date['month'];

    if(array_key_exists($indexDate,$casosArchivadosMes))
    {
        $casosArchivadosMes[$indexDate]++;
    }
    else{
        $casosArchivadosMes[$indexDate] = 0;
        $casosArchivadosMes[$indexDate] = $casosArchivadosMes[$indexDate] + 1;
    }
    $sumatoriaArchivadosMes = $sumatoriaArchivadosMes + 1;
}
?>


<?php
$sumatoriaIniciadosMes = 0;
$casosIniciadosMes = array();
$gsent = $pdo->prepare("SELECT fechaCarga FROM incidentes");
$gsent->execute();
$listadoIniciados = $gsent->fetchAll();
foreach ($listadoIniciados as &$valor) {

    $valor = $valor['fechaCarga'];
    $parsed_date = date_parse_from_format('Ym', $valor);
    $indexDate = $parsed_date['year'] . $parsed_date['month'];

    if(array_key_exists($indexDate,$casosIniciadosMes))
    {
        $casosIniciadosMes[$indexDate]++;
    }
    else{
        $casosIniciadosMes[$indexDate] = 0;
        $casosIniciadosMes[$indexDate] = $casosIniciadosMes[$indexDate] + 1;
    }
    $sumatoriaIniciadosMes = $sumatoriaIniciadosMes + 1;
}
?>

<!--  Tabla Detalle Indicador 1 -->
<?php

$gsent = $pdo->prepare("SELECT incidentes.id, persona.documento, tipo_incidente.nombre as nombreincidente, incidentes.fechaCarga, incidentes.fechaIncidente, estado_incidente.nombre as nombreestado FROM incidentes JOIN estado_incidente ON estado_incidente.id = incidentes.estado_id JOIN tipo_incidente ON tipo_incidente.id = incidentes.tipo_id JOIN usuarios ON usuarios.id = incidentes.usuario_id JOIN persona ON persona.id = usuarios.persona_id WHERE incidentes.estado_id in (SELECT estado_incidente.id FROM estado_incidente WHERE nombre IN (\"APROBADO\",\"RECHAZADO\")) ");
$gsent->execute();
$detallesIncidentesFinalizados = $gsent->fetchAll();

?>

<!--  Tabla Detalle Indicador 2 -->
<?php

$gsent = $pdo->prepare("SELECT incidentes.id, persona.documento, tipo_incidente.nombre as nombreincidente, incidentes.fechaCarga, incidentes.fechaIncidente, estado_incidente.nombre as nombreestado FROM incidentes JOIN estado_incidente ON estado_incidente.id = incidentes.estado_id JOIN tipo_incidente ON tipo_incidente.id = incidentes.tipo_id JOIN usuarios ON usuarios.id = incidentes.usuario_id JOIN persona ON persona.id = usuarios.persona_id ");
$gsent->execute();
$detallesIncidentes = $gsent->fetchAll();

?>



    <div id="wrapper">
        <!-- Navigation -->
        <?php include 'layout/navbar.php'; ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Indicadores</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <strong> Indicador 1 </strong>
                        </div>
                        <div class="panel-body">
                            <h4>Promedio de casos que finalizan con un resultado favorable para el beneficiario del incidente.</h4>

                            <!--
                            Definición: archivedCase ->	A completed instance of a process.
                            -->

                            <h1><?php
                                    echo ($finalizados/$countCases)>0?(round(($finalizados/$countCases)*100,2)):0;

                                ?>%</h1>

                            <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#indicador1">Ver Detalle</button>
                            <div id="indicador1" class="collapse" style="padding-top: 10px;">


                                <table class="table table-bordered" width="100%" id="tablaIndicador1" cellspacing="0">
                                    <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Cantidad</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">Total Casos Finalizados</th>
                                        <td><?php echo $countCases ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Total Casos Finalizados Favorables</th>
                                        <td><?php echo $finalizados ?></td>
                                    </tr>
                                    </tbody>
                                </table>



                                <p style="font-size: larger;color: red;">Información Detallada</p>

                                <table class="table table-bordered" width="100%" id="tablaIndicador1Detalle" cellspacing="0">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Documento</th>
                                        <th>Tipo</th>
                                        <th>Fecha Carga</th>
                                        <th>Fecha Incidente</th>
                                        <th>Estado</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                    foreach ($detallesIncidentesFinalizados as $valor) {
                                        ?><tr class="table-success"><?php
                                        ?><th scope="row"><?php echo $valor["id"]?></th>
                                        <td><?php echo $valor["documento"]?></td>
                                        <td><?php echo $valor["nombreincidente"]?></td>
                                        <td><?php echo $valor["fechaCarga"]?></td>
                                        <td><?php echo $valor["fechaIncidente"]?></td>
                                        <td><?php echo $valor["nombreestado"]?></td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>























                            </div>


                        </div>
                    </div>
                </div>
            </div>



            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            <strong> Indicador 2 </strong>
                        </div>
                        <div class="panel-body">
                            <h4>Promedio de casos que finalizan dentro del mes de iniciados.</h4>
                            <h1><?php echo round(($sumatoriaArchivadosMes/$sumatoriaIniciadosMes)*100,2) ?>%</h1>


                            <button type="button" class="btn btn-warning" data-toggle="collapse" data-target="#indicador2">Ver Detalle</button>

                            </br>

                            <div id="indicador2" class="collapse"  style="padding-top: 10px;">


                                <table class="table table-bordered" width="100%" id="tablaIndicador2" cellspacing="0">
                                <!-- <table class="table"> -->
                                    <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Iniciados</th>
                                        <th scope="col">Finalizados</th>
                                        <th scope="col">Promedio</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                    foreach ($casosIniciadosMes as $clave => $valor) {
                                        ?>
                                        <tr>
                                        <th scope="row"><?php echo $clave ?></th>
                                        <td><?php echo $valor ?></td>
                                        <td><?php echo (isset($casosArchivadosMes[$clave]))?$casosArchivadosMes[$clave]:0  ?></td>
                                        <td><?php echo round(($casosArchivadosMes[$clave] / $valor)*100,2) ?>%</td>
                                        </tr>
                                        <?php
                                    }
                                    ?>

                                    </tbody>
                                </table>



                                <p style="font-size: larger;color: red;">Información Detallada</p>
                                <table class="table table-bordered" width="100%" id="tablaIndicador2Detalle" cellspacing="0">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Documento</th>
                                        <th>Tipo</th>
                                        <th>Fecha Carga</th>
                                        <th>Fecha Incidente</th>
                                        <th>Estado</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                    foreach ($detallesIncidentes as $valor) {

                                        ?><tr class="table-success"><?php
                                        ?><th scope="row"><?php echo $valor["id"]?></th>
                                        <td><?php echo $valor["documento"]?></td>
                                        <td><?php echo $valor["nombreincidente"]?></td>
                                        <td><?php echo $valor["fechaCarga"]?></td>
                                        <td><?php echo $valor["fechaIncidente"]?></td>
                                        <td><?php echo $valor["nombreestado"]?></td>

                                        </tr>

                                        <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>








                            </div>

                        </div>
                    </div>
                </div>





            </div>

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    <?php include 'layout/defaultFooter.php'; ?>


<!-- DataTables JavaScript -->
<script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
<script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

<script>
    $(document).ready( function() {
        $('#tablaIndicador2').dataTable( {
            "language": {
                "lengthMenu": "Mostrar _MENU_ casos",
                "search": "Buscar: ",
                "info": "Mostrando _START_ de _END_ de un total de _TOTAL_ casos",
                "infoEmpty":      "No hay casos para mostrar",
                "zeroRecords":    "No hay casos para mostrar. Sin registros.",
                "emptyTable":     "Tabla vacía",
                "infoFiltered":   "(filtrados de un total de _MAX_ casos)",
                "paginate": {
                    "first":      "Primera",
                    "last":       "Última",
                    "next":       "Siguiente",
                    "previous":   "Anterior"
                },
                "aria": {
                    "sortAscending":  ": ordenar ascendente",
                    "sortDescending": ": ordenar descendente"
                }
            }
        } );

        $('#tablaIndicador1Detalle').dataTable( {
            "language": {
                "lengthMenu": "Mostrar _MENU_ casos",
                "search": "Buscar: ",
                "info": "Mostrando _START_ de _END_ de un total de _TOTAL_ casos",
                "infoEmpty":      "No hay casos para mostrar",
                "zeroRecords":    "No hay casos para mostrar. Sin registros.",
                "emptyTable":     "Tabla vacía",
                "infoFiltered":   "(filtrados de un total de _MAX_ casos)",
                "paginate": {
                    "first":      "Primera",
                    "last":       "Última",
                    "next":       "Siguiente",
                    "previous":   "Anterior"
                },
                "aria": {
                    "sortAscending":  ": ordenar ascendente",
                    "sortDescending": ": ordenar descendente"
                }
            }
        } );

        $('#tablaIndicador2Detalle').dataTable( {
            "language": {
                "lengthMenu": "Mostrar _MENU_ casos",
                "search": "Buscar: ",
                "info": "Mostrando _START_ de _END_ de un total de _TOTAL_ casos",
                "infoEmpty":      "No hay casos para mostrar",
                "zeroRecords":    "No hay casos para mostrar. Sin registros.",
                "emptyTable":     "Tabla vacía",
                "infoFiltered":   "(filtrados de un total de _MAX_ casos)",
                "paginate": {
                    "first":      "Primera",
                    "last":       "Última",
                    "next":       "Siguiente",
                    "previous":   "Anterior"
                },
                "aria": {
                    "sortAscending":  ": ordenar ascendente",
                    "sortDescending": ": ordenar descendente"
                }
            }
        } );



    } );
</script>


</body>

</html>
