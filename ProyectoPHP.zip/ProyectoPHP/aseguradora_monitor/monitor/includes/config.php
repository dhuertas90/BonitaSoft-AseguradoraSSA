<?php
namespace Monitor;

require '../classes/Access.php';
require '../classes/Request.php';
require '../classes/Users.php';
require '../classes/Process.php';
require '../classes/Cases.php';
require '../classes/Task.php';
require '../classes/Identity.php';
require '../mysql/ConnectionFactory.php';
require '../vendor/autoload.php';

session_start();

if (!Access::isLoggedIn() && $_SERVER['REQUEST_URI'] != '/monitor/pages/login.php') {
    header("Location: login.php");
    exit();
}
if (Access::isLoggedIn() && $_SERVER['REQUEST_URI'] == '/monitor/pages/login.php') {
    header("Location: index.php");
    exit();
}

$db_arguments = [
    'driver' => 'mysql',
    'host' => 'localhost',
    'user' => 'aseguradora_usr',
    'password' => 'aseguradora_pwd',
    'database' => 'aseguradora_db',
];

$pdo = (new ConnectionFactory($db_arguments))->getLink();