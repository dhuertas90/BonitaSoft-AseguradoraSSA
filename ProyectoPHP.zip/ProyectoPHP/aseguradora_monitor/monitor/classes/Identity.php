<?php

namespace Monitor;

class Identity {

    public static function getValidIdentityUsers($username){
        $response =  Request::doTheRequest('GET', 'API/identity/user?p=0&c=1&f=userName='.$username.'&f=manager_id=0');
        $validUser = $response['data'];
        if($validUser){
            return false;
        }
        return true;
    }
}